# IF03_ORACLE01 Authoring Report

## 1. Verdict

`ORACLE_AUTHORING_READY_FOR_INDEPENDENT_REVIEW`。八個 independently authored bounded synthetic SOURCE-BYTES **candidate expected**完整向量；64 named specification cases（58 mandatory+6 extra）。所有review_state、freeze_status均`PENDING_INDEPENDENT_REVIEW`。獨立性是本輪authoring未使用future/product Codec與repo serializer；不是外部review或實作驗收。

## 2. Source and Baseline Proof

Academic repo `/home/rooki/projects/pit-research-lab-mvp`；branch `main`；HEAD、origin/main、FETCH_HEAD均 `9ade777ac03052231088a91ef9849c5a506da184`。Scoped fetch已成功（no tags/no recurse-submodules），Git receipts在source_contract_inventory.json。開始與結束porcelain皆空；REPO_DIRTY_BEFORE=false、REPO_DIRTY_AFTER=false。兩份contract pin exact PASS；五個原始檔與HEAD blob相等。沒有read optional72,800-byte anchor、沒有WU03-A packet複本。

|Source path|Blob SHA-1|Bytes|Raw SHA-256|
|---|---|---:|---|
|docs/mvp/v1.0/shared-interface-contract-v0.1.md|d028005f6ac854fc3cde965b562dba4e449159cf|140871|66bef5b0bb8240214ec8ea14c3c94c8748e2944270883c56de3ae7f27355428b|
|docs/mvp/v1.0/ux-adr-01-temporal-execution-contract-v0.1.md|96d463c40a49d94e0b206be3851e26063fc6c581|23544|abb04bba20ce8640c38b2406aa662ae86ff3d6df892343b2e6d780c3073c01db|
|src/pit_research_lab/mvp/f2/synthetic_contracts.py|e7663d159c5bbd58a47ac2653daf5d2fbd2d42d9|20802|599b6005bd323aad64b3b541f0a0b84c7dd1982b31ade6f432645b1964f6ba56|
|src/pit_research_lab/mvp/f2/weekly_sequence.py|03a4fdcbcc7a653bcb06c3b3d38128cdd8bf3091|20140|367153643a98b29161d5b07502db0bbd3cce823a8867af3165177593f3a18fc2|
|tests/unit/mvp_f2/test_weekly_sequence.py|7e24dd09bbf21709cff8d9f8a82c2391735e4d3f|35485|8baac7d655a29d6698957b1339a4d1af66b373c6e86dfa025ef19dfce2518369|


所有表列檔案以完整raw bytes另存source_snapshots/*.txt，commit/blob/byte/SHA固定；條款來源CAN-01..10、AD01-08/09/10/11、RT01-01..05與UX ADOPT/RATIFY已閱讀。WU01 input_bytes/payload_pin L209–236只讀；weekly_sequence.py四個tick pins L63–68、flags L69–75、public __all__ L32與run_weekly_sequence均未執行。test_weekly_sequence.py L38–43/L295–382讀取為committed assertions，不當作本輪Native驗證。

原preflight fetch因shared Git metadata指到Formal root而停止，舊blocked包保留`/tmp/mvp-if03-oracle01-20261114T035318Z-boundary-stop`。Owner後續明確說 `I authorize you to access formal root`；本輪只對Academic checkout必要Git metadata使用該授權與sandbox escalation完成fetch。沒有列舉／讀取Formal source、runtime、credentials或其他sibling worktrees。不能宣稱零Formal-root metadata access；source/runtime保護仍維持。沒有Git stage/commit/push/PR/branch切換，fetch只更新授權metadata；無repository source/test/config/cache輸出。

RT01 L668/L720–739與UX L131–143是後來RATIFIED_EXACT overlay；ADOPT歷史CANDIDATE_FOR_OWNER_RATIFICATION不是veto。Ratification沒有freeze/full-domain/resource/runtime授權；本輪依user另授權bounded authoring。

## 3. Scope Accounting

|Class|Cases|
|---|---:|
|BLOCKED_BY_RESOURCE_SCHEMA|5|
|CONTRACT_REFUSAL_ONLY|21|
|DEFERRED_TO_FUTURE_DOMAIN_ORACLE|1|
|FRAMING_COMPONENT_EXACT_BYTES|4|
|RELATIONAL_ASSERTION_ONLY|11|
|SCALAR_FRAGMENT_EXACT_BYTES|14|
|VALID_COMPLETE_DOMAIN|8|


完整digests=8；scalar fragment cases=14；framing component cases=4；refusal specification cases=21；relational assertion cases=11；blocked5+deferred1=6；合計64。Substimuli不增加case數。O01=14、O02=12、O03=12、O04=8、O05=6、O06=6；L01..L06=6補充。逐case精確source pointers、status與disposition如下，亦與Scope Register/JSON相符。

|ID|Class|Input / 期望|Clause|Status / prerequisite|
|---|---|---|---|---|
|S01|SCALAR_FRAGMENT_EXACT_BYTES|Int64 0：type 排在 value 之前；兩欄 typed record，外部 domain 層未提供。 下列完整 bytes 僅為 typed scalar fragment；不是完整 CanonicalPayload<D>。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|S02|SCALAR_FRAGMENT_EXACT_BYTES|Int64 140：直接依文法重建 documentary scalar。 下列完整 bytes 僅為 typed scalar fragment；不是完整 CanonicalPayload<D>。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739, AD01-08 documentary bytes, not a domain L493–499|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|S03|SCALAR_FRAGMENT_EXACT_BYTES|Int64 min -9223372036854775808。 下列完整 bytes 僅為 typed scalar fragment；不是完整 CanonicalPayload<D>。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|S04|SCALAR_FRAGMENT_EXACT_BYTES|Int64 max 9223372036854775807。 下列完整 bytes 僅為 typed scalar fragment；不是完整 CanonicalPayload<D>。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|S05|SCALAR_FRAGMENT_EXACT_BYTES|UInt64 zero 0。 下列完整 bytes 僅為 typed scalar fragment；不是完整 CanonicalPayload<D>。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|S06|SCALAR_FRAGMENT_EXACT_BYTES|UInt64 max 18446744073709551615。 下列完整 bytes 僅為 typed scalar fragment；不是完整 CanonicalPayload<D>。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|S07|SCALAR_FRAGMENT_EXACT_BYTES|schema-declared Boolean component：ScopeFlags.diagnostic_only=true / admission_eligible=false。 true/false 是 Boolean token；兩欄不能單獨宣稱完整 ScopeFlags 或 domain。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739, AD01-09 ScopeFlags / ScopeRecord L532–533|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|S08|CONTRACT_REFUSAL_ONLY|Int64 max+1 與 min-1。 拒絕範圍溢位；不截斷、不成功 digest/reference。|AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|S09|CONTRACT_REFUSAL_ONLY|UInt64 max+1 與 -1。 拒絕 UInt64 範圍／符號；不成功 digest/reference。|AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|S10|CONTRACT_REFUSAL_ONLY|+1、01、-0、bare 140。 前三者拒絕非 canonical decimal spelling；bare token 拒絕未 typed numeric；無成功 digest/reference。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|S11|CONTRACT_REFUSAL_ONLY|Bool↔Int coercion；Python bool 是 int subclass 亦不得作為 Int64。 Boolean field 的 1/0 與 Int64 value=true 均拒絕；Python True→Int64(1) conversion 也拒絕；無成功 digest/reference。|AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|S12|BLOCKED_BY_RESOURCE_SCHEMA|Decimal coefficient=0、scale=0 對比 scale=6。 0×10^0 與 0×10^-6 數值相等但 declared scale 不同；不得合併 bytes。完整 Decimal blocked，無 domain digest/reference。|AD01-07.CAN-02 L457–458, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739|POSITIVE_OBJECT_BLOCKED；Approved NUMERIC_POLICY raw bytes/schema、ResourceRef semantic owner review 與 enclosing domain prerequisites 未提供。|
|S13|CONTRACT_REFUSAL_ONLY|Decimal exponent / float / scale19 / negative scale。 拒絕 exponent spelling、floating coefficient、scale>18、negative UInt64 scale；不 rounding，不成功完整物件或 digest。|AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|S14|BLOCKED_BY_RESOURCE_SCHEMA|FixedRatio6 components：0.500000 與500000、scale6；mismatch500001。 agreement: 0.500000 ↔500000/10^6、unit FRACTION、scale6；mismatch500001 或非六位 text、scale≠6、units>1000000 應拒絕。完整正向物件 blocked；不是 A05 attestation。|AD01-07.CAN-02 L457–458, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739|POSITIVE_OBJECT_BLOCKED；FIXED_SIX_DECIMAL_FRACTION_HALF_EVEN-v0.1 的 approved NUMERIC_POLICY body/schema 與 ResourceRef 尚未提供。|
|J01|SCALAR_FRAGMENT_EXACT_BYTES|ASCII string、quote 與 backslash escaping。 原字元 A、雙引號、反斜線、Z；quote→5c22、backslash→5c5c。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|J02|SCALAR_FRAGMENT_EXACT_BYTES|NFC é 對比 e+U+0301；不 normalize。 NFC bytes 22c3a922 與 decomposed 2265cc8122 不同；無 domain digest。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|J03|SCALAR_FRAGMENT_EXACT_BYTES|中文「中文」literal UTF-8。 字串內容 e4b8ad e69687，共6 bytes；加 quotes 共8 bytes，不用非 ASCII \u escape。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|J04|SCALAR_FRAGMENT_EXACT_BYTES|LF、Tab、NUL、U+001F lower-case control escapes。 順序0a09001f→字串中 \u000a\u0009\u0000\u001f；short escape 合法 JSON 但非 canonical bytes claim。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|J05|SCALAR_FRAGMENT_EXACT_BYTES|scrambled ASCII keys 的 grammar-only component。 依 unsigned UTF-8 bytes 排序 A、_k、a、a0、z；此 component 沒有 registered enclosing schema，不是 domain。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|J06|SCALAR_FRAGMENT_EXACT_BYTES|array [a,b] vs [b,a]。 兩者 preserve order 且 bytes 不同；不排序 arrays。|AD01-07.CAN-01 L455–456, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|J07|CONTRACT_REFUSAL_ONLY|duplicate JSON key 在 map collapse 前拒絕。 拒絕 duplicate key；不得 last-wins 或 first-wins；無成功 digest/reference。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|J08|CONTRACT_REFUSAL_ONLY|SOURCE-BYTES exact schema：未知欄與缺 required body_sha256。 拒絕 unknown 或 missing required field；不 strip、填空或成功 digest/reference。|AD01-07.CAN-01 L455–456, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739, AD01-09 exact SOURCE-BYTES fields L507–511|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|J09|CONTRACT_REFUSAL_ONLY|SOURCE-BYTES 的 explicit null、omitted、NotEvaluated 都不是 body_sha256 Hex64。 null 拒絕，omitted 缺欄拒絕，NotEvaluated tag 無法代替 Hex64；Unknown/NotApplicable/Withheld 亦不自動 substitution，無 empty default/digest/reference。|AD01-07.CAN-01 L455–456, AD01-07.CAN-07 L467–468, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|J10|CONTRACT_REFUSAL_ONLY|bare number、NaN、Infinity、float。 全部無 typed canonical numeric 表示；拒絕，無成功 digest/reference。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|J11|CONTRACT_REFUSAL_ONLY|Canonical UTF-8 BOM、invalid UTF-8、unpaired surrogate。 BOM 與 malformed UTF-8 拒絕；\ud800/\udc00 拒絕；opaque body ff 可在 B06 成功，不能把 body 與 canonical text 混用。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|J12|SCALAR_FRAGMENT_EXACT_BYTES|Text UTF-8 content byte limit65536，並非 character count；以 compact stimulus 指定。 é×32768=65536 content bytes，符合 Text component bound；再加 ASCII A=65537 拒絕。JSON quotes/escaping 不計入 Text 的原 UTF-8 content 長度，payload另有 bound。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739|CANDIDATE_FRAGMENT_BYTES；無此 case 的額外 resource prerequisite|
|F01|FRAMING_COMPONENT_EXACT_BYTES|LP64BE empty segment。 component only；D/S/P各自有非空約束，此零段不能當合法完整 frame。|AD01-07.CAN-04 L461–462, RT01-03 limited normative overlay L716–739|CANDIDATE_COMPONENT_BYTES；無此 case 的額外 resource prerequisite|
|F02|FRAMING_COMPONENT_EXACT_BYTES|LP64BE ASCII A。 length1 加41，共9 bytes；無 official domain digest。|AD01-07.CAN-04 L461–462, RT01-03 limited normative overlay L716–739|CANDIDATE_COMPONENT_BYTES；無此 case 的額外 resource prerequisite|
|F03|FRAMING_COMPONENT_EXACT_BYTES|LP64BE é UTF-8=2 bytes。 prefix=2，非1個 code point。|AD01-07.CAN-04 L461–462, RT01-03 limited normative overlay L716–739|CANDIDATE_COMPONENT_BYTES；無此 case 的額外 resource prerequisite|
|F04|FRAMING_COMPONENT_EXACT_BYTES|實際 registered SOURCE-BYTES D43/S27。 完整 D/S components；自身不是完整 payload/frame/identity。|AD01-07.CAN-04 L461–462, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739, AD01-09 registry L505–511|CANDIDATE_COMPONENT_BYTES；無此 case 的額外 resource prerequisite|
|F05|RELATIONAL_ASSERTION_ONLY|B02 complete frame 三段 offsets。 引用 B02 正向 vector：D[8,51)、S[59,86)、P[94,281)；prefix在0/51/86，共281 bytes，無尾資料。|AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|F06|RELATIONAL_ASSERTION_ONLY|B02 BODY vs payload-audit vs FRAME hash。 只有 SHA256(B02/frame.bin) 是 B02 candidate domain digest；raw_body/payload hash 是不同 preimage，不能替換。觀察本 sample 三值各異，不泛稱無 collision。|AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|F07|CONTRACT_REFUSAL_ONLY|swap D/S、foreign registered tuple、unsupported SCALAR toy。 無合法 registry tuple 就拒絕；即使 frame bytes變了也不發新 identity。D/S 與 {} toy只可教學，不成功 digest/reference。|AD01-07.CAN-04 L461–462, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|F08|CONTRACT_REFUSAL_ONLY|profile omitted、只放 Envelope、改 v1.0。 即使 asserted digest 相同也拒絕缺/錯 profile；不從 envelope 補 P。|AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|F09|RELATIONAL_ASSERTION_ONLY|Envelope length 是 payload187，非 frame281。 B02 expected envelope canonical_payload_byte_length=typed UInt64("187")；若填281必須拒絕；envelope不進入自己的P。|AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|F10|CONTRACT_REFUSAL_ONLY|wrong prefix、truncated frame、trailing byte。 三種均拒絕 malformed framing；不讀過尾或忽略多餘bytes；無成功 digest/reference。|AD01-07.CAN-04 L461–462, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|F11|CONTRACT_REFUSAL_ONLY|own digest/envelope/locator 進 P。 own envelope / digest inclusion 依 AD01-08 為 documented REF_CYCLE；locator extra field 同時違反 exact schema。無循環 hash 或成功 reference。|AD01-07.CAN-01 L455–456, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-08 REF_CYCLE L489|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|F12|CONTRACT_REFUSAL_ONLY|uppercase digest、unsupported algorithm/version。 64 lowercase digest 格式、SHA-256 literal 與精確 registry版本皆必需；wrong values拒絕，不 downgrade或成功 reference。|AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|B01|VALID_COMPLETE_DOMAIN|Empty raw body；UInt64 includes0，SOURCE-BYTES ExactFields 沒有 body 最小長度；payload仍為非空187 bytes。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|B02|VALID_COMPLETE_DOMAIN|ASCII A。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|B03|VALID_COMPLETE_DOMAIN|一個 NUL byte。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|B04|VALID_COMPLETE_DOMAIN|NFC é 的2個 UTF-8 raw bytes。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|B05|VALID_COMPLETE_DOMAIN|decomposed e+U+0301 的3個 raw bytes。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|B06|VALID_COMPLETE_DOMAIN|Opaque raw ff，不是 CanonicalPayload 的 UTF-8；raw body 不須作文字解碼。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|B07|VALID_COMPLETE_DOMAIN|A 後接 raw LF0a；raw body 不經 JSON escaping。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|B08|VALID_COMPLETE_DOMAIN|B02 的一個 byte mutation：B。 CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。|AD01-07.CAN-01 L455–456, AD01-07.CAN-02 L457–458, AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, AD01-09 SOURCE-BYTES exact field registry L505–511, AD01-08 exact framing/envelope L475–503|CANDIDATE_EXPECTED_BYTES；無此 case 的額外 resource prerequisite|
|T01|RELATIONAL_ASSERTION_ONLY|D2 AT t1 cutoff：2027-01-07T18:00:00+08:00。 strict published_at < cutoff；AT 不等於 BEFORE，D2 不可進 t1；原 declaration SECOND / Asia/Taipei / +08:00 保留，不做完整 TimeRecord hash。|AD01-07.CAN-03 L459–460, AD01-07.CAN-05 L463–464, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|T02|RELATIONAL_ASSERTION_ONLY|D3 at t3+1 second。 2027-01-29T18:00:01+08:00 > cutoff18:00:00；D3 不可進 t3；time rules absent 時不建立完整 TimeRecord。|AD01-07.CAN-03 L459–460, AD01-07.CAN-05 L463–464, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|T03|RELATIONAL_ASSERTION_ONLY|t2/t3 同 D2 bytes/version/value，不同決策 context。 t2 2027-01-15 與 t3 2027-01-29 cutoff/context 不同；D2/150/0.733333 是既有 committed assertions；新 QUAL/OBS identity 要依新 domain parents/resources，不能複用或發 present digest。|AD01-07.CAN-03 L459–460, AD01-07.CAN-05 L463–464, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739, AD01-10 M01 L559|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|T04|RELATIONAL_ASSERTION_ONLY|2027-W03 NO_SESSION_WEEK 不是第五 Tick。 四個日期01-07/01-15/01-29/02-05；annotation order/內容屬 schedule evidence，不能補一個 no-session Tick；無 sequence digest。|AD01-07.CAN-03 L459–460, AD01-07.CAN-05 L463–464, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|T05|CONTRACT_REFUSAL_ONLY|naive / fractional / contradictory zone-offset / missing rules。 naive、fractional seconds、Asia/Taipei 宣告卻offset+09:00等矛盾必須拒絕；named-zone語義須 pinned rules，缺少時拒絕 unavailable rules，不查 host tzdb；無成功 TimeRecord/domain digest。|AD01-07.CAN-03 L459–460, AD01-07.CAN-05 L463–464, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；Approved TIMEZONE_RULES body/schema、origin ResourceRef 與 domain parents 未提供；contradiction 為規格預期，未執行 timezone 驗證。|
|T06|BLOCKED_BY_RESOURCE_SCHEMA|相同 UTC instant，不同 declaration/origin 的 identity sensitivity。 可比較 SAME_INSTANT；原 zone/text/origin 仍是 evidence，不可 normalize丟棄；不同 valid zone 要 future broadened profile，不能當目前合法正向。無完整 TimeRecord 或 QUAL digest。|AD01-07.CAN-03 L459–460, AD01-07.CAN-05 L463–464, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739|POSITIVE_OBJECT_BLOCKED；Pinned reviewed TIMEZONE_RULES/schema、ORIGIN resources 與 broader valid declaration profile 未提供。|
|I01|RELATIONAL_ASSERTION_ONLY|SOURCE-BYTES 僅 immutable raw body integrity。 raw body固定，外部 publisher/time/version/rights assertion變動不改 body payload；可以 invalidate qualification/access；hash不產生 publisher、歷史PIT或來源 authentication。|AD01-07.CAN-04 L461–462, AD01-07.CAN-05 L463–464, RT01-03 limited normative overlay L716–739, SOURCE-BYTES claim L511, AD01-10 M21 L579|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|I02|RELATIONAL_ASSERTION_ONLY|WU01/S3/A04/A05/B03/WU04 local preimages 不同。 不能由既有 hashes 或1,813-byte detached read 推定等於新 App identity。這是 preimage/claim boundary，不宣稱跨hash永無collision；本輪不執行既有 modules。|AD01-07.CAN-01 L455–456, AD01-07.CAN-06 L465–466, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|I03|BLOCKED_BY_RESOURCE_SCHEMA|要求完整 F2-QUALIFICATION。 阻擋完整 positive object；不能用 placeholder refs補 MANIFEST/CALENDAR/COVERAGE/TIMEZONE_RULES/SEMANTIC_TRACE、code/Native state/source history；無成功digest/reference。|AD01-07.CAN-03 L459–460, AD01-07.CAN-05 L463–464, AD01-07.CAN-06 L465–466, RT01-03 limited normative overlay L716–739, AD01-09 F2-QUALIFICATION L512|POSITIVE_OBJECT_BLOCKED；Owner reviewed approved raw resource bytes/schema、qualified source parents、rules/code/Native trace/rights 未提供。|
|I04|BLOCKED_BY_RESOURCE_SCHEMA|要求 F2-OBSERVATION / TEMPORAL-SEQUENCE。 缺 qualified parents、projection/release/config/schedule/policies時 blocked，不能成功空集合；partial sequence/duplicate/swapped/dropped/foreign Tick拒絕 fixed WU04 release。|AD01-07.CAN-05 L463–464, AD01-07.CAN-07 L467–468, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739, AD01-09 OBSERVATION / SEQUENCE L513–514|POSITIVE_OBJECT_BLOCKED；Accepted F2-QUALIFICATION parents、PROJECTION_POLICY、OBSERVATION_RELEASE_POLICY、TEMPORAL_CONFIGURATION、DECISION_SCHEDULE、CALENDAR 與 SEMANTIC_TRACE exact schemas/bytes。|
|I05|DEFERRED_TO_FUTURE_DOMAIN_ORACLE|F3/F5 experiment/policy/result/attempt/evidence full identity。 defer domain oracle；不以空metrics、fake outputs或placeholder Parents製造成功digest。SOURCE-BYTES expected envelope也不提供 resource semantic approval。|AD01-07.CAN-05 L463–464, AD01-07.CAN-06 L465–466, AD01-07.CAN-08 L469–470, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739, AD01-09 remaining domain schemas L515–520|FUTURE_DOMAIN_NOT_AUTHORED；F3/F5 owner protocols、method、maturity、metric、policy/outcome、actual attempt receipts、semantic evidence 與 rights review 未提供。|
|I06|RELATIONAL_ASSERTION_ONLY|Native A / production Codec B / F3-F5 / IF05 / IF07 未執行。 本輪所有 runtime/conformance/Native replay NOT_RUN；IF-05/IF-07與Codec/F3/F5 execution NOT_AUTHORIZED。RUN / VALUE_AVAILABLE / SUPPORTED / SELECTED 不授予 ELIGIBLE，四項diagnostic scope旗標與disposition保留。|AD01-07.CAN-07 L467–468, AD01-07.CAN-08 L469–470, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739, AD01-11 two-channel gate L618–632|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|L01|CONTRACT_REFUSAL_ONLY|CanonicalPayload limit16777216、LP prefix越界。 16777217-byte requested P 拒絕 allocation之前；0-byte P也拒絕。界內大小只是 length predicate，不保證 schema/type有效。無16MiB fixture/digest。|AD01-07.CAN-04 L461–462, RT01-03 limited normative overlay L716–739|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|L02|CONTRACT_REFUSAL_ONLY|Record depth≤64，超過64拒絕。 65個巢狀 records（root亦為record）超過 bound；不 truncation，不成功digest。root depth起算慣例尚需 future codec邊界決策，本例刻意用66層以在0/1起算均超限。|AD01-07.CAN-01 L455–456, RT01-03 limited normative overlay L716–739, AD01-07 common bounds L441|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|L03|CONTRACT_REFUSAL_ONLY|Array limit4096。 4097 items 拒絕；4096只滿足 collection bound，仍須 domain schema、membership/rights。無大fixture/digest。|AD01-07.CAN-01 L455–456, AD01-07.CAN-09 L471–472, RT01-03 limited normative overlay L716–739, AD01-07 common bounds L441|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|L04|CONTRACT_REFUSAL_ONLY|Role IDs/versions與 D/S bound128 bytes。 ASCII role ID/version129 bytes拒絕；D/S length0/129拒絕。exact registry tuple仍另外必須匹配；無成功digest。|AD01-07.CAN-01 L455–456, AD01-07.CAN-04 L461–462, RT01-03 limited normative overlay L716–739, AD01-09 Text bounds L528|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|L05|CONTRACT_REFUSAL_ONLY|foreign/stale/dangling parent、cycle 與 resource substitution。 parent typed domain mismatch、stale/dangling/reordered chain、subject→own EVIDENCE cycle拒絕；unknown/unreviewed Resource schema拒絕 documented REF_UNAPPROVED_RESOURCE_SCHEMA。僅 specification，不捏造 accepted graph/digest。|AD01-07.CAN-05 L463–464, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739, Resource schema refusal L549|DOCUMENTARY_REFUSAL_NOT_EXECUTED；無此 case 的額外 resource prerequisite|
|L06|RELATIONAL_ASSERTION_ONLY|code drift、fresh attempt與 same deterministic content。 相關 Native code drift按M24使依賴qualification改變或block replay；無 relevant closure不可假設無關。M27/M28 fresh actual attempt/clock不改固定 deterministic RESULT，但新attempt receipt不同。此輪無實際reissue/result hash。|AD01-07.CAN-06 L465–466, AD01-07.CAN-08 L469–470, AD01-07.CAN-10 L473–474, RT01-03 limited normative overlay L716–739, AD01-10 M24/M27/M28/M34 L582–592|DOCUMENTARY_RELATION_NOT_EXECUTED；無此 case 的額外 resource prerequisite|


## 4. CAN-01..10 Clause Matrix

|Clause|固定source lines|本輪coverage / limitation|
|---|---|---|
|CAN-01|455–456|S/J fragments、B exact ASCII payload；J07..J11 documentary refusals；L02/L03/L04 compact bounds|
|CAN-02|457–458|S01..S11 exact fragment/refusal；S12/S14 full resource positive blocked；S13 refusal；B typed UInt64|
|CAN-03|459–460|T01..T04 relation、T05 refusal、T06 blocked；無host tzdb或full TimeRecord hash|
|CAN-04|461–462|F01..F04 LP components、B01..B08 complete frames、F05/F06/F09 relations、其他F documentary拒絕、L01 bounds|
|CAN-05|463–464|B expected六欄Envelope；S12/S14/T06/I03/I04 resource gates；F11/L05 self/parent拒絕|
|CAN-06|465–466|I02/L06 local/code provenance relation；I03完整qualification blocked，無observed code執行聲稱|
|CAN-07|467–468|J09 tag/null refusal、I04不可empty success、I06 invocation與PIT分離；無fabricated first failure|
|CAN-08|469–470|I05 domains deferred、I06 NOT_RUN、L06 fresh attempt relation；無actual new execution|
|CAN-09|471–472|J06 array order、T04 annotation、I04 fixed profile拒絕；無完整sequence graph/digest|
|CAN-10|473–474|F07/F08/F12/L05 strict negotiation、I02 local identity分離、I05 defer；無migration/TypeScript parity|


全部為expected specification/fragment coverage，不是64個executed product conformance tests；AUTHOR_SELF_CHECK的2034個內部assertions亦不是產品測試數。

## 5. SOURCE-BYTES Golden Candidate Table

|ID|Raw hex|Raw bytes|P bytes|Frame bytes|BODY SHA-256|FRAME SHA-256|Artifacts|
|---|---|---:|---:|---:|---|---|---|
|B01|(empty)|0|187|281|e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855|687ddd2e1d12816f5e20e505af0bb9d6f149ddf218e7f37a6eb6dc13df3ea686|[full derivation](vectors/B01/derivation.md), [raw](vectors/B01/raw_body.bin), [payload](vectors/B01/canonical_payload.bin), [frame](vectors/B01/frame.bin)|
|B02|41|1|187|281|559aead08264d5795d3909718cdd05abd49572e84fe55590eef31a88a08fdffd|11bb5c86b5c41d57b1fde3e55bb766b529bb4afe2a439a1a3a7fee8875f8cf5f|[full derivation](vectors/B02/derivation.md), [raw](vectors/B02/raw_body.bin), [payload](vectors/B02/canonical_payload.bin), [frame](vectors/B02/frame.bin)|
|B03|00|1|187|281|6e340b9cffb37a989ca544e6bb780a2c78901d3fb33738768511a30617afa01d|be5b9bbb19b6a656803fc7ba81996f91446d1fd377e451e60767625b98cfac3d|[full derivation](vectors/B03/derivation.md), [raw](vectors/B03/raw_body.bin), [payload](vectors/B03/canonical_payload.bin), [frame](vectors/B03/frame.bin)|
|B04|c3a9|2|187|281|4a99557e4033c3539de2eb65472017cad5f9557f7a0625a09f1c3f6e2ba69c4c|af2c85ddf4d4bc4c271c15e2806f367e07287c1d6a35ae992f3d3e4d3752ed61|[full derivation](vectors/B04/derivation.md), [raw](vectors/B04/raw_body.bin), [payload](vectors/B04/canonical_payload.bin), [frame](vectors/B04/frame.bin)|
|B05|65cc81|3|187|281|bf12767b0f2a56b2190075bae8169f656e3ce8d6357d4aff184bc6c7ea48f9f6|cb8bdd239329aa1d95308a88e36583c2285027c26a7711a89f9dab077886a387|[full derivation](vectors/B05/derivation.md), [raw](vectors/B05/raw_body.bin), [payload](vectors/B05/canonical_payload.bin), [frame](vectors/B05/frame.bin)|
|B06|ff|1|187|281|a8100ae6aa1940d0b663bb31cd466142ebbdbd5187131b92d93818987832eb89|55daae37a193963e214e9a67415fe8c17eecafea0b13e54919b774f05d991970|[full derivation](vectors/B06/derivation.md), [raw](vectors/B06/raw_body.bin), [payload](vectors/B06/canonical_payload.bin), [frame](vectors/B06/frame.bin)|
|B07|410a|2|187|281|06f961b802bc46ee168555f066d28f4f0e9afdf3f88174c1ee6f9de004fc30a0|7fd81935e350dc4cdb2ce57ab39377f16a1be43314d393f75837945f04e51a12|[full derivation](vectors/B07/derivation.md), [raw](vectors/B07/raw_body.bin), [payload](vectors/B07/canonical_payload.bin), [frame](vectors/B07/frame.bin)|
|B08|42|1|187|281|df7e70e5021544f4834bbee64a9e3789febc4be81470df629cad6ddb03320a5c|a405fcdaeb1277046d4d9038029e05c4bd633692d305afc0b964086443c232a8|[full derivation](vectors/B08/derivation.md), [raw](vectors/B08/raw_body.bin), [payload](vectors/B08/canonical_payload.bin), [frame](vectors/B08/frame.bin)|


B01允許原因：CAN-02 UInt64範圍含0，AD01-09 SOURCE-BYTES沒有額外body非空限制；CAN-04的payload length>=1約束P，不約束raw body。本例P187，不用空P冒充。B06允許原因：SOURCE-BYTES欄位取exact raw body bytes/hash，UTF-8規則約束canonical payload；opaque ff不解碼，P仍合法UTF-8。請Independent Reviewer明確challenge兩項解讀。

每個B有raw_body.bin、canonical_payload.bin、frame.bin與全hex；可解碼的artifact另有逐bytes相同UTF-8檔。expected.json含六欄expected envelope；derivation.md含raw hex、手數length、完整P文字與hex、完整frame hex與hash。B02→B08與B04→B05在sample上raw SHA、P、frame SHA均不同。SHA-256 collision resistance是integrity假設，未聲稱數學無collision。

共同claim：`CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION`。沒有Resource schema批准、issuer/resolver capability或admitted SnapshotReference。

## 6. Frame Dissection & ReferenceEnvelope Rules

D是ASCII43 bytes，S是ASCII27 bytes。LP(D) prefix[0,8)=000000000000002b，D[8,51)；LP(S) prefix[51,59)=000000000000001b，S[59,86)；LP(P) prefix[86,94)=00000000000000bb，P[94,281)。end281，無trailing data。總長24+43+27+187=281。

P literal片段長度46+raw-length一位數1+18+raw-sha64+profile suffix58=187。精確鍵序body_byte_length、body_sha256、canonical_profile_version；UInt64內層type、value。Profile `typed-json-candidate-v0.1`在P內；Envelope長度typed UInt64187，不是281。Envelope精確domain_tag/object_schema_version/canonical_profile_version/digest_algorithm/canonical_payload_byte_length/digest_hex，OWN envelope/digest/locator不在P；standalone SOURCE-BYTES不需要ParentRef。

BODY SHA=SHA256(raw_body.bin)；FRAME SHA=SHA256(frame.bin)；payload SHA僅以expected_payload_sha256_audit_only記錄。Unsupported D/S toy只是F07 invalid input；沒有toy digest或新SCALAR domain。

## 7. Negative/Mutation and Blocked Case Matrix

完整矩陣見section3與Scope Register。S08..S11/S13、J07..J11、F07/F08/F10..F12、T05、L01..L05共21 documentary refusals；沒有聲稱產品已返回error。既有REF_CYCLE（AD01-08 L489）、REF_UNAPPROVED_RESOURCE_SCHEMA（AD01-09 L549）可引用，其餘用拒絕category敘述，不創造error constants。

S12/S14 Numeric policy resource、T06 timezone/origin resources、I03 qualification closure、I04 observation/sequence parents/policies blocked；I05 F3/F5/EVIDENCE future domain deferred。無placeholder refs hash。T05混合刺激全部主張不可成功：格式不合法或unpinned rules拒絕；不使用host timezone資料代替。

WU04 t1 strict AT非BEFORE、t3+1s、t2/t3 D2相同但context不同、W03非fifth tick均是關係cases，源於pinned文字/assertions，不重新生成WU01/A05或完整F2 canonical hashes。S3/A04/A05/B03既有local preimages保持分離；diagnostic_only=True、admission_eligible=False、NOT_TRUSTED_PIT_EVIDENCE、NOT_ESTABLISHED、INTEGRATED_PROVISIONAL不升級。

## 8. Oracle Independence Assessment

Author是本次Codex assistant。原raw samples以explicit hex literal獨立寫出；S/J strings與numeric records由各case literal/hex建構，沒有generic serializer。SOURCE-BYTES只用明列的三fields literal拼接，D/S與LP64BE prefix亦固定可檢查；JSON dumps只寫外部metadata，未用來產生canonical payload。沒有import repo、canonical_codec、Native owner或WU01 input_bytes。

Python 3.14.4 standard library hashlib對**已寫出的**raw_body.bin/frame.bin計算SHA；stdout列完整八組BODY/FRAME hashes。實際command、interpreter、source SHA、stdout/stderr與checksum見execution/author_cases.receipt.json；primitive計算是工具結果，不是心算。author_cases.executed-v0.py保留真正首次執行source；更新template author_cases.py未重跑，R1 helper已對candidate套用同樣修正。

R1修正手算片段說明44→46/60→58（sum187未變），並補J12 exact quoted-unit bytes。8組raw/P/frame與digests均未改。candidate_revision_log.json記前後檔SHA；不涉及normative rule變動。self_check.py獨立於author helper，以strict parsing、fixed-layout regex、literal constants、segment parsing核對；結果PASS，只是AUTHOR_SELF_CHECK_ONLY。

## 9. Unresolved Contract Ambiguities

此bounded八組SOURCE-BYTES沒有發現需要改contract的blocking ambiguity。B01/B06的適用規則與推理已明列供challenge。Record depth的root起算慣例未在文件另給可執行算法；L02用66層以在常見0/1起算皆超64，不聲稱解決未來64/65精準邊界；future Codec先由contract review確認計數再做該正向邊界。不是本輪默改規則。

外部Resource bodies/schemas與time/policy/rights並非可自行補齊的ambiguity；affected positives明確blocked。沒有owner-policy attestation、runtime acceptance或全域identity equivalence。

## 10. Deferred Gates

TIMEZONE_RULES、NUMERIC_POLICY、完整F2/F3/F5及EVIDENCE resources/parents、IF-04 capabilities、IF-05 predicates、IF-07 real-source rights/history、Native Replay Channel A、production Codec/Channel B、TypeScript parity、consumer handoff、Golden Freeze與Git integration均未完成／未授權。本輪Native/pytest/Makefile/services/database/real providers完全NOT_RUN，無新PIT claim。

## 11. Artifact Manifest and Exact Delivery Paths

Root `/tmp/mvp-if03-oracle01-20261114T040238Z`；report `/tmp/mvp-if03-oracle01-20261114T040238Z/IF03_ORACLE01_Authoring_Report.md`；scope `/tmp/mvp-if03-oracle01-20261114T040238Z/oracle_scope_register.json`；handoff `/tmp/mvp-if03-oracle01-20261114T040238Z/IF03_ORACLE01_Independent_Review_HandOff.md`；ZIP `/tmp/mvp-if03-oracle01-20261114T040238Z/IF03_ORACLE01_Review_Evidence.zip`。

MANIFEST.json列ZIP中除其自身外所有member的排序relative path、byte_length與SHA-256；沒有self hash。SHA256SUMS在ZIP外涵蓋所有ZIP members（含manifest）與ZIP本體；package_validation.json和packaging stdout/stderr為ZIP外delivery receipts，避免archive自hash循環。ZIP SHA-256的實際值記在該外部receipt、SHA256SUMS與最終交付訊息；不嵌入會改變自身ZIP hash的內部report。

Packager會驗證CRC、完整manifest coverage、member byte/SHA、safe paths、無duplicate/encryption/symlink/hardlink，然後獨立delivery script再次核對，任一不合格不handoff。檔案皆外部regular single-link copies，source snapshots不是hardlinks；無下載依賴。Reviewer步驟與fresh preimage要求見獨立handoff。

## 12. Explicit Next Authority Request

`INDEPENDENT_REVIEW_OF_EXACT_ORACLE_BYTES` **only**。請另一位reviewer核實完整bytes、refusal及blocker，再另交獨立verdict。freeze_status=`PENDING_INDEPENDENT_REVIEW`；本輪不要求Commit/Push/Merge或Codec implementation，亦不宣稱IF03_GOLDEN_ORACLE_FROZEN、IF03_DOMAIN_IDENTITY_ACCEPTED、CANONICAL_CODEC_ACCEPTED、REPLAY_ACCEPTED、PIT_VERIFIED、F2_HANDOFF_ACCEPTED或F3_F5_READY。
