# Independent Oracle Review HandOff

唯一下一個authority event：`INDEPENDENT_REVIEW_OF_EXACT_ORACLE_BYTES`。本作者並非此包的 Independent Reviewer；`INDEPENDENT_REVIEW=NOT_RUN`。不得先freeze或實作Codec。

1. 先驗證 ZIP SHA-256（ZIP外 SHA256SUMS）、CRC、manifest精確coverage與每個member的bytes/SHA；拒絕absolute/..、duplicates、encrypted/link members。MANIFEST不含自身；SHA256SUMS和delivery receipt在ZIP外。ZIP內所有其他檔都須被MANIFEST涵蓋。
2. 確認base `9ade777ac03052231088a91ef9849c5a506da184`、五個source snapshots raw SHA與Git blob，兩份contract pins和原始lines。查看authorization amendment：Owner後續文字授權Formal root，本輪僅用於Academic checkout shared Git metadata；Formal source/runtime未探查。先前blocked包留在原位置，不能與此包混用。
3. 必須直接讀取B02、B03、B04、B06、B08的raw_body.bin：41 / 00 / c3a9 / ff / 42。從CAN-01/02、AD01-09三個fields與原body重新寫自己的payload，不複製作者payload/frame，不rerun author_cases.py作為唯一review。
4. Fresh preimages：D=`PITLAB/ACADEMIC/SOURCE-BYTES/candidate-v0.1`、S=`source-bytes-candidate-v0.1`。根據自己算的byte lengths組三個LP64BE段；逐byte比對作者frame，再以standard primitive計算fresh SHA-256。B01/B05/B07也要確認，B01尤其挑戰UInt64 zero、SOURCE-BYTES無額外非空body限制；P必須非空，不能混淆body/P。
5. 所有8個SOURCE-BYTES同為P187/frame281，但不要先信這兩個數；手算literal片段46+1+18+64+58。prefix offsets0/51/86、data8/59/94，end281。檢查expected envelope精確六欄與payload-only length187，profile在P內且OWN digest/envelope/locator在外。B01空body與B06 opaque ff不代表CanonicalPayload可invalid UTF-8。
6. Sensitive fragments：S01/S02/S03/S04/S06、S07 Boolean、J01 quote/backslash、J02 NFC/NFD、J03中文、J04全部所列controls、J12 content-byte界線。檢查Int overflow、+1/01/-0、bool↔int、Decimal scale保存及FixedRatio6 policy缺席。S12/S14不得因component bytes而發完整resource identity。
7. 主動challenge duplicate-before-map、null/omission/tag substitution、short escapes、BOM/surrogates、swapped domain/schema、profile只在Envelope、malformed/trailing frame、uppercase digest、self-envelope、BODY/FRAME confusion、foreign/stale/dangling parent與cycle。Refusal只有specification，production Codec NOT_RUN；不要把作者self-check當已觀察拒絕。
8. 全64 rows逐一對clause而非只對counter；必須確認58 mandatory均涵蓋其contrast。T01 AT非BEFORE、T02 t3+1s、T03 D2同值不同context與原四pins、T04 W03非第五Tick；無reviewed TIMEZONE_RULES就不能發TimeRecord/F2 positive。無policy/resource schema亦不准補placeholder refs。
9. 查candidate_revision_log.json：R1僅修手算片段長度說明44→46/60→58並增加J12 quoted-unit artifact；8個positive raw/P/frame/hash完全不變。原執行helper保留為author_cases.executed-v0.py，其SHA對應author_cases.receipt；更新template未重跑。不能將此作者修正當Independent Review通過。
10. Discrepancies用P0/P1/P2分級，給固定commit/path/line、實際observed byte offset、expected vs observed與最小remediation；獨立提供verdict。只有全部充分justify才可建議Owner對**limited scope exact manifest/pins**另行Freeze，不得替Owner批准、Git integrate、發reference或接受Replay/PIT/IF05/IF07。

最低可重建材料：五份原始source snapshots、完整literal raw body/bin/hex、每個B的full payload UTF-8與frame hex、逐段offset derivation、expected envelope fields。metadata numeric/null不是App encoding。

外部需要的hash command可用reviewer自己寫的standard-library程式或 `sha256sum <fresh-frame-file>`。作者現有primitive是在Python 3.14.4，輸入explicit *.bin，實際argv/stdout/stderr與stdout checksum見execution/*.receipt.json；這只證明作者工具計算，未取代reviewer重建。
