"""Bounded literal evidence authoring. No general JSON/App codec; no repo imports."""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INV = json.loads((ROOT / 'source_contract_inventory.json').read_text())
assert INV['contract_pin_status'] == 'PASS'
SHARED = INV['sources'][0]
UX = INV['sources'][1]
LOCAL = INV['sources'][2]
WEEKLY = INV['sources'][3]
TEST = INV['sources'][4]
V = []
FRAGMENT = 'SCALAR_FRAGMENT_EXACT_BYTES'
COMPONENT = 'FRAMING_COMPONENT_EXACT_BYTES'
REFUSE = 'CONTRACT_REFUSAL_ONLY'
BLOCKED = 'BLOCKED_BY_RESOURCE_SCHEMA'
RELATION = 'RELATIONAL_ASSERTION_ONLY'
DEFERRED = 'DEFERRED_TO_FUTURE_DOMAIN_ORACLE'
COMPLETE = 'VALID_COMPLETE_DOMAIN'
CAN_LINES = {i: 453 + 2*i for i in range(1, 11)}

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def pointer(src, lines, clause):
    return {'repo_path': src['repo_path'], 'commit': src['commit'],
            'git_blob_sha1': src['git_blob_sha1'], 'lines': lines, 'clause': clause}

def add(vid, cls, title, cans, outcome, blocked=None, extra=None):
    row = dict(vector_id=vid, vector_version='oracle01-candidate-v0.1', **{'class': cls},
        contract_clause_pointer=[pointer(SHARED, [CAN_LINES[c], CAN_LINES[c]+1], f'AD01-07.CAN-{c:02}') for c in cans]
          + [pointer(SHARED, [716,739], 'RT01-03 limited normative overlay')],
        source_ref='SELF_CONTAINED_SYNTHETIC', input_description=title,
        exact_input_bytes_hex={}, exact_scalar_or_payload_bytes_hex={}, exact_frame_bytes_hex=None,
        expected_raw_sha256=None, expected_frame_sha256=None, expected_envelope_fields=None,
        expected_relation_or_refusal=outcome,
        status={COMPLETE:'CANDIDATE_EXPECTED_BYTES', FRAGMENT:'CANDIDATE_FRAGMENT_BYTES', COMPONENT:'CANDIDATE_COMPONENT_BYTES',
                REFUSE:'DOCUMENTARY_REFUSAL_NOT_EXECUTED', BLOCKED:'POSITIVE_OBJECT_BLOCKED',
                RELATION:'DOCUMENTARY_RELATION_NOT_EXECUTED', DEFERRED:'FUTURE_DOMAIN_NOT_AUTHORED'}[cls],
        blocked_prerequisite=blocked, authoring_method='Case-specific literal bytes / documentary contract reasoning; SHA-256 only over explicit files when applicable',
        limitations=['AUTHOR_SELF_CHECK_ONLY; product Codec/conformance tests NOT_RUN',
                     'No issued reference, source authentication, PIT admission, Native replay or Golden Freeze'],
        review_state='PENDING_INDEPENDENT_REVIEW', artifacts=[], components={})
    if extra:
        row.update(extra)
    V.append(row)
    return row

def art(row, name, body, role):
    assert isinstance(body, bytes)
    folder = ROOT / 'vectors' / row['vector_id']
    folder.mkdir(parents=True, exist_ok=True)
    binpath = folder / (name + '.bin')
    with binpath.open('xb') as f:
        f.write(body)
    hexpath = folder / (name + '.hex')
    hexpath.write_text(body.hex() + '\n', encoding='ascii')
    item = {'name': name, 'role': role, 'bin': binpath.relative_to(ROOT).as_posix(),
            'hex': hexpath.relative_to(ROOT).as_posix(), 'byte_length': len(body)}
    try:
        rendered = body.decode('utf-8')
    except UnicodeDecodeError:
        item['utf8_rendering'] = 'UNDEFINED_INVALID_UTF8'
    else:
        # UTF-8 rendering is a literal file, possibly empty; no appended newline.
        textpath = folder / (name + '.utf8.txt')
        textpath.write_bytes(rendered.encode('utf-8'))
        item['utf8_file'] = textpath.relative_to(ROOT).as_posix()
    row['artifacts'].append(item)
    if role == 'INPUT':
        row['exact_input_bytes_hex'][name] = body.hex()
    elif role in {'SCALAR_OR_PAYLOAD', 'FRAMING_COMPONENT'}:
        row['exact_scalar_or_payload_bytes_hex'][name] = body.hex()
    elif role == 'FRAME':
        assert row['class'] == COMPLETE
        row['exact_frame_bytes_hex'] = body.hex()
    return body

def frag(vid, title, literal):
    row = add(vid, FRAGMENT, title, [1,2], '下列完整 bytes 僅為 typed scalar fragment；不是完整 CanonicalPayload<D>。')
    art(row, 'scalar', literal, 'SCALAR_OR_PAYLOAD')
    return row

frag('S01', 'Int64 0：type 排在 value 之前；兩欄 typed record，外部 domain 層未提供。', b'{"type":"int64","value":"0"}')
frag('S02', 'Int64 140：直接依文法重建 documentary scalar。', b'{"type":"int64","value":"140"}')
V[-1]['contract_clause_pointer'].append(pointer(SHARED,[493,499],'AD01-08 documentary bytes, not a domain'))
frag('S03', 'Int64 min -9223372036854775808。', b'{"type":"int64","value":"-9223372036854775808"}')
frag('S04', 'Int64 max 9223372036854775807。', b'{"type":"int64","value":"9223372036854775807"}')
frag('S05', 'UInt64 zero 0。', b'{"type":"uint64","value":"0"}')
frag('S06', 'UInt64 max 18446744073709551615。', b'{"type":"uint64","value":"18446744073709551615"}')
r=add('S07', FRAGMENT, 'schema-declared Boolean component：ScopeFlags.diagnostic_only=true / admission_eligible=false。', [1,2], 'true/false 是 Boolean token；兩欄不能單獨宣稱完整 ScopeFlags 或 domain。')
r['contract_clause_pointer'].append(pointer(SHARED,[532,533],'AD01-09 ScopeFlags / ScopeRecord'))
art(r,'diagnostic_only_true',b'true','SCALAR_OR_PAYLOAD');art(r,'admission_eligible_false',b'false','SCALAR_OR_PAYLOAD')
r=add('S08',REFUSE,'Int64 max+1 與 min-1。',[2],'拒絕範圍溢位；不截斷、不成功 digest/reference。')
art(r,'above_max',b'{"type":"int64","value":"9223372036854775808"}','INPUT');art(r,'below_min',b'{"type":"int64","value":"-9223372036854775809"}','INPUT')
r=add('S09',REFUSE,'UInt64 max+1 與 -1。',[2],'拒絕 UInt64 範圍／符號；不成功 digest/reference。')
art(r,'above_max',b'{"type":"uint64","value":"18446744073709551616"}','INPUT');art(r,'negative',b'{"type":"uint64","value":"-1"}','INPUT')
r=add('S10',REFUSE,'+1、01、-0、bare 140。',[1,2],'前三者拒絕非 canonical decimal spelling；bare token 拒絕未 typed numeric；無成功 digest/reference。')
for name, literal in [('plus',b'{"type":"int64","value":"+1"}'),('zero_prefix',b'{"type":"int64","value":"01"}'),('negative_zero',b'{"type":"int64","value":"-0"}'),('bare',b'140')]:art(r,name,literal,'INPUT')
r=add('S11',REFUSE,'Bool↔Int coercion；Python bool 是 int subclass 亦不得作為 Int64。',[2],'Boolean field 的 1/0 與 Int64 value=true 均拒絕；Python True→Int64(1) conversion 也拒絕；無成功 digest/reference。')
r['components']['typed_call_stimuli']=[{'declared_type':'Int64','host_type':'bool','host_value':True},{'declared_type':'Boolean','host_type':'int','host_value':1}]
art(r,'bool_as_int',b'{"type":"int64","value":true}','INPUT');art(r,'int_as_bool_field',b'{"diagnostic_only":1}','INPUT')
r=add('S12',BLOCKED,'Decimal coefficient=0、scale=0 對比 scale=6。',[2,5], '0×10^0 與 0×10^-6 數值相等但 declared scale 不同；不得合併 bytes。完整 Decimal blocked，無 domain digest/reference。', 'Approved NUMERIC_POLICY raw bytes/schema、ResourceRef semantic owner review 與 enclosing domain prerequisites 未提供。')
for name,literal in [('coefficient_zero',b'{"type":"int64","value":"0"}'),('scale_zero',b'{"type":"uint64","value":"0"}'),('scale_six',b'{"type":"uint64","value":"6"}')]:art(r,name,literal,'SCALAR_OR_PAYLOAD')
r=add('S13',REFUSE,'Decimal exponent / float / scale19 / negative scale。',[2],'拒絕 exponent spelling、floating coefficient、scale>18、negative UInt64 scale；不 rounding，不成功完整物件或 digest。')
for name,literal in [('coefficient_exponent',b'{"type":"int64","value":"1e2"}'),('coefficient_float',b'1.5'),('scale19',b'{"type":"uint64","value":"19"}'),('scale_negative',b'{"type":"uint64","value":"-1"}')]:art(r,name,literal,'INPUT')
r['components']['scale19_context']='UInt64(19) 本身 scalar 合法；只在 Decimal.scale 欄超出0..18。'
r=add('S14',BLOCKED,'FixedRatio6 components：0.500000 與500000、scale6；mismatch500001。',[2,5], 'agreement: 0.500000 ↔500000/10^6、unit FRACTION、scale6；mismatch500001 或非六位 text、scale≠6、units>1000000 應拒絕。完整正向物件 blocked；不是 A05 attestation。', 'FIXED_SIX_DECIMAL_FRACTION_HALF_EVEN-v0.1 的 approved NUMERIC_POLICY body/schema 與 ResourceRef 尚未提供。')
for name,literal in [('decimal_text',b'"0.500000"'),('scaled_units',b'{"type":"uint64","value":"500000"}'),('scale',b'{"type":"uint64","value":"6"}'),('unit',b'"FRACTION"')]:art(r,name,literal,'SCALAR_OR_PAYLOAD')
r['components']['documentary_mismatches']=[{'decimal_text':'0.500000','scaled_units':'500001'}, {'decimal_text':'0.5','scaled_units':'500000'}, {'scale':'5'}, {'scaled_units':'1000001'}]

r=add('J01',FRAGMENT,'ASCII string、quote 與 backslash escaping。',[1],'原字元 A、雙引號、反斜線、Z；quote→5c22、backslash→5c5c。')
art(r,'original_text',bytes.fromhex('41225c5a'),'INPUT');art(r,'quoted_string',bytes.fromhex('22415c225c5c5a22'),'SCALAR_OR_PAYLOAD')
r=add('J02',FRAGMENT,'NFC é 對比 e+U+0301；不 normalize。',[1],'NFC bytes 22c3a922 與 decomposed 2265cc8122 不同；無 domain digest。')
art(r,'nfc_text',bytes.fromhex('c3a9'),'INPUT');art(r,'nfd_text',bytes.fromhex('65cc81'),'INPUT')
art(r,'nfc_quoted',bytes.fromhex('22c3a922'),'SCALAR_OR_PAYLOAD');art(r,'nfd_quoted',bytes.fromhex('2265cc8122'),'SCALAR_OR_PAYLOAD')
r=add('J03',FRAGMENT,'中文「中文」literal UTF-8。',[1],'字串內容 e4b8ad e69687，共6 bytes；加 quotes 共8 bytes，不用非 ASCII \\u escape。')
art(r,'text',bytes.fromhex('e4b8ade69687'),'INPUT');art(r,'quoted',bytes.fromhex('22e4b8ade6968722'),'SCALAR_OR_PAYLOAD')
r=add('J04',FRAGMENT,'LF、Tab、NUL、U+001F lower-case control escapes。',[1],'順序0a09001f→字串中 \\u000a\\u0009\\u0000\\u001f；short escape 合法 JSON 但非 canonical bytes claim。')
art(r,'controls',bytes.fromhex('0a09001f'),'INPUT');art(r,'escaped',b'"\\u000a\\u0009\\u0000\\u001f"','SCALAR_OR_PAYLOAD');art(r,'noncanonical_short',b'"\\n\\t\\u0000\\u001f"','INPUT')
r=add('J05',FRAGMENT,'scrambled ASCII keys 的 grammar-only component。',[1],'依 unsigned UTF-8 bytes 排序 A、_k、a、a0、z；此 component 沒有 registered enclosing schema，不是 domain。')
art(r,'scrambled',b'{"z":"last","a0":"zero","a":"first","_k":"under","A":"upper"}','INPUT')
art(r,'sorted',b'{"A":"upper","_k":"under","a":"first","a0":"zero","z":"last"}','SCALAR_OR_PAYLOAD')
r=add('J06',FRAGMENT,'array [a,b] vs [b,a]。',[1,9],'兩者 preserve order 且 bytes 不同；不排序 arrays。')
art(r,'ab',b'["a","b"]','SCALAR_OR_PAYLOAD');art(r,'ba',b'["b","a"]','SCALAR_OR_PAYLOAD')
r=add('J07',REFUSE,'duplicate JSON key 在 map collapse 前拒絕。',[1],'拒絕 duplicate key；不得 last-wins 或 first-wins；無成功 digest/reference。')
art(r,'duplicate',b'{"body_sha256":"a","body_sha256":"b"}','INPUT')

# Explicit complete SOURCE-BYTES preimages. All raw lengths are hand-counted single digits.
# Exactly this domain/schema, three literal payload fields and constant LP lengths; not a serializer.
D = b'PITLAB/ACADEMIC/SOURCE-BYTES/candidate-v0.1'
S = b'source-bytes-candidate-v0.1'
assert len(D)==43 and len(S)==27
body_cases = [
 ('B01','', '0','Empty raw body；UInt64 includes0，SOURCE-BYTES ExactFields 沒有 body 最小長度；payload仍為非空187 bytes。'),
 ('B02','41','1','ASCII A。'),
 ('B03','00','1','一個 NUL byte。'),
 ('B04','c3a9','2','NFC é 的2個 UTF-8 raw bytes。'),
 ('B05','65cc81','3','decomposed e+U+0301 的3個 raw bytes。'),
 ('B06','ff','1','Opaque raw ff，不是 CanonicalPayload 的 UTF-8；raw body 不須作文字解碼。'),
 ('B07','410a','2','A 後接 raw LF0a；raw body 不經 JSON escaping。'),
 ('B08','42','1','B02 的一個 byte mutation：B。'),
]
positive = {}
for vid, hx, length_text, desc in body_cases:
    r=add(vid,COMPLETE,desc,[1,2,4,5], 'CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION；candidate expected envelope 不是 issued capability。')
    r['contract_clause_pointer'] += [pointer(SHARED,[505,511],'AD01-09 SOURCE-BYTES exact field registry'),pointer(SHARED,[475,503],'AD01-08 exact framing/envelope')]
    raw=art(r,'raw_body',bytes.fromhex(hx),'INPUT')
    assert str(len(raw))==length_text
    raw_sha=hashlib.sha256((ROOT/'vectors'/vid/'raw_body.bin').read_bytes()).hexdigest()
    p=(b'{"body_byte_length":{"type":"uint64","value":"'+length_text.encode('ascii')+
       b'"},"body_sha256":"'+raw_sha.encode('ascii')+
       b'","canonical_profile_version":"typed-json-candidate-v0.1"}')
    assert len(p)==187
    art(r,'canonical_payload',p,'SCALAR_OR_PAYLOAD')
    f=(bytes.fromhex('000000000000002b')+D+bytes.fromhex('000000000000001b')+S+
       bytes.fromhex('00000000000000bb')+p)
    assert len(f)==281
    art(r,'frame',f,'FRAME')
    digest=hashlib.sha256((ROOT/'vectors'/vid/'frame.bin').read_bytes()).hexdigest()
    env={'domain_tag':D.decode('ascii'),'object_schema_version':S.decode('ascii'),
         'canonical_profile_version':'typed-json-candidate-v0.1','digest_algorithm':'SHA-256',
         'canonical_payload_byte_length':{'type':'uint64','value':'187'},'digest_hex':digest}
    r.update(expected_raw_sha256=raw_sha, expected_frame_sha256=digest, expected_envelope_fields=env,
        domain_tag=D.decode(),object_schema_version=S.decode(),canonical_profile_version='typed-json-candidate-v0.1',
        raw_body_byte_length=int(length_text),canonical_payload_byte_length=187,frame_byte_length=281,
        expected_payload_sha256_audit_only=hashlib.sha256(p).hexdigest(),
        hash_method={'interpreter':'Python 3 standard-library hashlib.sha256',
            'command':'python3 -B '+str(Path(__file__)),
            'raw_input_file':'vectors/'+vid+'/raw_body.bin','frame_input_file':'vectors/'+vid+'/frame.bin',
            'output_receipt':'execution/author_cases.stdout.txt (manifest pins entire stdout)'},
        frame_dissection=[{'segment':'domain','prefix_start':0,'prefix_end_exclusive':8,'prefix_hex':'000000000000002b','byte_length':43,'data_start':8,'data_end_exclusive':51},
            {'segment':'schema','prefix_start':51,'prefix_end_exclusive':59,'prefix_hex':'000000000000001b','byte_length':27,'data_start':59,'data_end_exclusive':86},
            {'segment':'payload','prefix_start':86,'prefix_end_exclusive':94,'prefix_hex':'00000000000000bb','byte_length':187,'data_start':94,'data_end_exclusive':281}])
    derivation=f'''# {vid} 手工可重建 preimage

來源 SELF_CONTAINED_SYNTHETIC；CAN-01/02/04/05、AD01-09 L507–511，RT01-03 L716–739。

raw hex（空即0 bytes）：`{hx}`；手工 raw length：{length_text}。
raw SHA-256（hashlib 計算，不是心算）：`{raw_sha}`。

三個欄依 b < c 排序，body_byte_length < body_sha256；內層 type < value。全長為187：

```json
{p.decode()}
```

完整 payload hex：`{p.hex()}`。
Payload 長度算式：`len('{{"body_byte_length":{{"type":"uint64","value":"')=44 + 1 digit + len('"}},"body_sha256":"')=18 + 64 hex + len('","canonical_profile_version":"typed-json-candidate-v0.1"}}')=60`；以實際文字逐 byte 核對為準（另見自檢）。

Domain ASCII43 bytes：`{D.decode()}`；hex `{D.hex()}`。
Schema ASCII27 bytes：`{S.decode()}`；hex `{S.hex()}`。

|segment|prefix [start,end)|length bytes|data [start,end)|
|---|---|---|---|
|D|[0,8)|43 = 0x2b|[8,51)|
|S|[51,59)|27 = 0x1b|[59,86)|
|P|[86,94)|187 = 0xbb|[94,281)|

三個 LP64BE prefix：000000000000002b、000000000000001b、00000000000000bb。
Frame length =24+43+27+187=281；完整 frame hex：`{f.hex()}`。

FRAME SHA-256：`{digest}`。
Payload SHA-256（audit-only，非 domain digest）：`{r['expected_payload_sha256_audit_only']}`。
BODY SHA 與 FRAME SHA 分別命名；不相互代用。expected.json 的 envelope 精確六個 core fields，length=187（payload only），不在 P 裡。

{desc}
此為 candidate expected artifact，尚未 issued、independently reviewed 或 frozen。
'''
    (ROOT/'vectors'/vid/'derivation.md').write_text(derivation,encoding='utf-8')
    positive[vid] = (r,raw,p,f)
    print(f'{vid} BODY_SHA256={raw_sha} PAYLOAD_BYTES=187 FRAME_BYTES=281 FRAME_SHA256={digest}')

P = positive['B02'][2]
F = positive['B02'][3]
r=add('J08',REFUSE,'SOURCE-BYTES exact schema：未知欄與缺 required body_sha256。',[1,10],'拒絕 unknown 或 missing required field；不 strip、填空或成功 digest/reference。')
r['contract_clause_pointer'].append(pointer(SHARED,[507,511],'AD01-09 exact SOURCE-BYTES fields'))
art(r,'unknown',P[:-1]+b',"extension":"x"}','INPUT')
missing=P[:P.index(b',"body_sha256"')]+P[P.index(b',"canonical_profile_version"'):]
art(r,'missing_body_sha',missing,'INPUT')
r=add('J09',REFUSE,'SOURCE-BYTES 的 explicit null、omitted、NotEvaluated 都不是 body_sha256 Hex64。',[1,7],'null 拒絕，omitted 缺欄拒絕，NotEvaluated tag 無法代替 Hex64；Unknown/NotApplicable/Withheld 亦不自動 substitution，無 empty default/digest/reference。')
start=P.index(b'"body_sha256":')+len(b'"body_sha256":');end=P.index(b',"canonical_profile_version"')
for name,value in [('null',b'null'),('not_evaluated',b'{"owner":"F2","reason":"absent","type":"not_evaluated"}')]:art(r,name,P[:start]+value+P[end:],'INPUT')
art(r,'omitted',missing,'INPUT')
r=add('J10',REFUSE,'bare number、NaN、Infinity、float。',[1,2],'全部無 typed canonical numeric 表示；拒絕，無成功 digest/reference。')
for name,literal in [('bare',b'140'),('nan',b'NaN'),('infinity',b'Infinity'),('negative_infinity',b'-Infinity'),('float',b'1.5')]:art(r,name,literal,'INPUT')
r=add('J11',REFUSE,'Canonical UTF-8 BOM、invalid UTF-8、unpaired surrogate。',[1],'BOM 與 malformed UTF-8 拒絕；\\ud800/\\udc00 拒絕；opaque body ff 可在 B06 成功，不能把 body 與 canonical text 混用。')
for name,literal in [('bom_payload',bytes.fromhex('efbbbf')+P),('invalid_utf8',b'"\xff"'),('high_surrogate',b'"\\ud800"'),('low_surrogate',b'"\\udc00"')]:art(r,name,literal,'INPUT')
r=add('J12',FRAGMENT,'Text UTF-8 content byte limit65536，並非 character count；以 compact stimulus 指定。',[1],'é×32768=65536 content bytes，符合 Text component bound；再加 ASCII A=65537 拒絕。JSON quotes/escaping 不計入 Text 的原 UTF-8 content 長度，payload另有 bound。')
art(r,'unit_e_acute',bytes.fromhex('c3a9'),'INPUT')
r['components']['compact_boundary_stimuli']=[{'recipe':'repeat raw unit c3a9 32768 times','content_bytes':65536,'expected':'Text length predicate satisfied; not complete domain'}, {'recipe':'same plus ASCII41','content_bytes':65537,'expected':'Refuse Text bound'}]

r=add('F01',COMPONENT,'LP64BE empty segment。',[4],'component only；D/S/P各自有非空約束，此零段不能當合法完整 frame。')
art(r,'segment',b'','INPUT');art(r,'lp_empty',bytes.fromhex('0000000000000000'),'FRAMING_COMPONENT')
r=add('F02',COMPONENT,'LP64BE ASCII A。',[4],'length1 加41，共9 bytes；無 official domain digest。')
art(r,'segment',b'A','INPUT');art(r,'lp_A',bytes.fromhex('000000000000000141'),'FRAMING_COMPONENT')
r=add('F03',COMPONENT,'LP64BE é UTF-8=2 bytes。',[4],'prefix=2，非1個 code point。')
art(r,'segment',bytes.fromhex('c3a9'),'INPUT');art(r,'lp_e',bytes.fromhex('0000000000000002c3a9'),'FRAMING_COMPONENT')
r=add('F04',COMPONENT,'實際 registered SOURCE-BYTES D43/S27。',[4,10],'完整 D/S components；自身不是完整 payload/frame/identity。')
r['contract_clause_pointer'].append(pointer(SHARED,[505,511],'AD01-09 registry'))
art(r,'domain_ascii',D,'FRAMING_COMPONENT');art(r,'schema_ascii',S,'FRAMING_COMPONENT')
r=add('F05',RELATION,'B02 complete frame 三段 offsets。',[4,5],'引用 B02 正向 vector：D[8,51)、S[59,86)、P[94,281)；prefix在0/51/86，共281 bytes，無尾資料。')
r['components']['target_vector']='B02';r['components']['decomposition']=positive['B02'][0]['frame_dissection']
r=add('F06',RELATION,'B02 BODY vs payload-audit vs FRAME hash。',[4,5],'只有 SHA256(B02/frame.bin) 是 B02 candidate domain digest；raw_body/payload hash 是不同 preimage，不能替換。觀察本 sample 三值各異，不泛稱無 collision。')
r['components']['target_vector']='B02'
r=add('F07',REFUSE,'swap D/S、foreign registered tuple、unsupported SCALAR toy。',[4,10],'無合法 registry tuple 就拒絕；即使 frame bytes變了也不發新 identity。D/S 與 {} toy只可教學，不成功 digest/reference。')
art(r,'swapped_D_S_frame',bytes.fromhex('000000000000001b')+S+bytes.fromhex('000000000000002b')+D+bytes.fromhex('00000000000000bb')+P,'INPUT')
art(r,'unsupported_toy',bytes.fromhex('00000000000000014400000000000000015300000000000000027b7d'),'INPUT')
r['components']['foreign_tuple']={'domain_tag':D.decode(),'object_schema_version':'f2-observation-candidate-v0.1','expected':'Refuse exact tuple mismatch, no successful digest'}
r=add('F08',REFUSE,'profile omitted、只放 Envelope、改 v1.0。',[4,5,10],'即使 asserted digest 相同也拒絕缺/錯 profile；不從 envelope 補 P。')
art(r,'profile_omitted',P[:P.index(b',"canonical_profile_version"')]+b'}','INPUT')
art(r,'profile_altered',P.replace(b'typed-json-candidate-v0.1',b'typed-json-v1.0'),'INPUT')
r['components']['envelope_only_profile']='P has no profile; caller supplies correct profile in envelope; still refusal'
r=add('F09',RELATION,'Envelope length 是 payload187，非 frame281。',[4,5],'B02 expected envelope canonical_payload_byte_length=typed UInt64("187")；若填281必須拒絕；envelope不進入自己的P。')
r['components']['target_vector']='B02'
r=add('F10',REFUSE,'wrong prefix、truncated frame、trailing byte。',[4],'三種均拒絕 malformed framing；不讀過尾或忽略多餘bytes；無成功 digest/reference。')
art(r,'wrong_domain_length',bytes.fromhex('000000000000002a')+F[8:],'INPUT');art(r,'truncated',F[:-1],'INPUT');art(r,'trailing',F+b'\x00','INPUT')
r=add('F11',REFUSE,'own digest/envelope/locator 進 P。',[1,5],'own envelope / digest inclusion 依 AD01-08 為 documented REF_CYCLE；locator extra field 同時違反 exact schema。無循環 hash 或成功 reference。')
r['contract_clause_pointer'].append(pointer(SHARED,[489,489],'AD01-08 REF_CYCLE'))
for name,suffix in [('digest',b',"digest_hex":"asserted"}'),('envelope',b',"reference_envelope":{}}'),('locator',b',"locator":"self"}')]:art(r,'own_'+name,P[:-1]+suffix,'INPUT')
r=add('F12',REFUSE,'uppercase digest、unsupported algorithm/version。',[4,5,10],'64 lowercase digest 格式、SHA-256 literal 與精確 registry版本皆必需；wrong values拒絕，不 downgrade或成功 reference。')
r['components']['envelope_field_mutations']=[{'digest_hex':positive['B02'][0]['expected_frame_sha256'].upper()}, {'digest_algorithm':'SHA-512'}, {'object_schema_version':'source-bytes-candidate-v0.2'}, {'domain_tag':'PITLAB/ACADEMIC/SOURCE-BYTES/candidate-v0.2'}]

def temporal(vid, cls, title, outcome, blocked=None):
    r=add(vid,cls,title,[3,5,9],outcome,blocked)
    r['source_ref']=[pointer(UX,[119,119],'ADOPT-01 WU04 bounded illustration'),pointer(UX,[139,139],'RATIFY-01 diagnostic/time constraints'),pointer(WEEKLY,[63,75],'four original tick SHA-256s and scope flags'),pointer(TEST,[295,382],'committed time/context assertions; NOT_RUN here')]
    return r
r=temporal('T01',RELATION,'D2 AT t1 cutoff：2027-01-07T18:00:00+08:00。','strict published_at < cutoff；AT 不等於 BEFORE，D2 不可進 t1；原 declaration SECOND / Asia/Taipei / +08:00 保留，不做完整 TimeRecord hash。')
r['components']['times']={'cutoff_source_text':'2027-01-07T18:00:00+08:00','published_source_text':'2027-01-07T18:00:00+08:00','derived_utc_comparison':'2027-01-07T10:00:00Z','relation':'AT; not BEFORE','origin_ref':'preserve original origin; not reconstructed here'}
r=temporal('T02',RELATION,'D3 at t3+1 second。','2027-01-29T18:00:01+08:00 > cutoff18:00:00；D3 不可進 t3；time rules absent 時不建立完整 TimeRecord。')
r['components']['times']={'cutoff':'2027-01-29T18:00:00+08:00','published':'2027-01-29T18:00:01+08:00','relation':'AFTER'}
r=temporal('T03',RELATION,'t2/t3 同 D2 bytes/version/value，不同決策 context。','t2 2027-01-15 與 t3 2027-01-29 cutoff/context 不同；D2/150/0.733333 是既有 committed assertions；新 QUAL/OBS identity 要依新 domain parents/resources，不能複用或發 present digest。')
r['contract_clause_pointer'].append(pointer(SHARED,[559,559],'AD01-10 M01'))
r['components']['wu04_tick_sha256_pins']=['909050c0cc90f0e16361891e9fa2b2233a363aa35de5278a38b838d97baea046','be50dadac52fee5a266b56dbd4448275cf331078af554050713bcdf4471fe1fa','56c8ca0ff123301adc894e65738209c7987e91d31a9c9b35597e3ae44c0abed8','beaf6dff59c87f22f9384a5d1ce3017a1192dbf2167e51b0c9b54d389eb107e8']
r=temporal('T04',RELATION,'2027-W03 NO_SESSION_WEEK 不是第五 Tick。','四個日期01-07/01-15/01-29/02-05；annotation order/內容屬 schedule evidence，不能補一個 no-session Tick；無 sequence digest。')
r=temporal('T05',REFUSE,'naive / fractional / contradictory zone-offset / missing rules。','naive、fractional seconds、Asia/Taipei 宣告卻offset+09:00等矛盾必須拒絕；named-zone語義須 pinned rules，缺少時拒絕 unavailable rules，不查 host tzdb；無成功 TimeRecord/domain digest。','Approved TIMEZONE_RULES body/schema、origin ResourceRef 與 domain parents 未提供；contradiction 為規格預期，未執行 timezone 驗證。')
r['components']['stimuli']=[{'source_text':'2027-01-07T18:00:00'}, {'source_text':'2027-01-07T18:00:00.001+08:00'}, {'source_text':'2027-01-07T18:00:00+09:00','timezone_name':'Asia/Taipei','offset':'+09:00'}, {'timezone_rules_ref':'ABSENT (descriptive stimulus, no placeholder hashed)'}]
r=temporal('T06',BLOCKED,'相同 UTC instant，不同 declaration/origin 的 identity sensitivity。','可比較 SAME_INSTANT；原 zone/text/origin 仍是 evidence，不可 normalize丟棄；不同 valid zone 要 future broadened profile，不能當目前合法正向。無完整 TimeRecord 或 QUAL digest。','Pinned reviewed TIMEZONE_RULES/schema、ORIGIN resources 與 broader valid declaration profile 未提供。')

r=add('I01',RELATION,'SOURCE-BYTES 僅 immutable raw body integrity。',[4,5], 'raw body固定，外部 publisher/time/version/rights assertion變動不改 body payload；可以 invalidate qualification/access；hash不產生 publisher、歷史PIT或來源 authentication。')
r['contract_clause_pointer'] += [pointer(SHARED,[511,511],'SOURCE-BYTES claim'),pointer(SHARED,[579,579],'AD01-10 M21')]
r=add('I02',RELATION,'WU01/S3/A04/A05/B03/WU04 local preimages 不同。',[1,6,10], '不能由既有 hashes 或1,813-byte detached read 推定等於新 App identity。這是 preimage/claim boundary，不宣稱跨hash永無collision；本輪不執行既有 modules。')
r['source_ref']=[pointer(LOCAL,[209,236],'input_bytes ensure_ascii=True / payload_pin'),pointer(SHARED,[551,551],'AD01-09 distinct local identities'),pointer(WEEKLY,[339,380],'detached diagnostic read')]
r=add('I03',BLOCKED,'要求完整 F2-QUALIFICATION。',[3,5,6], '阻擋完整 positive object；不能用 placeholder refs補 MANIFEST/CALENDAR/COVERAGE/TIMEZONE_RULES/SEMANTIC_TRACE、code/Native state/source history；無成功digest/reference。','Owner reviewed approved raw resource bytes/schema、qualified source parents、rules/code/Native trace/rights 未提供。')
r['contract_clause_pointer'].append(pointer(SHARED,[512,512],'AD01-09 F2-QUALIFICATION'))
r=add('I04',BLOCKED,'要求 F2-OBSERVATION / TEMPORAL-SEQUENCE。',[5,7,9], '缺 qualified parents、projection/release/config/schedule/policies時 blocked，不能成功空集合；partial sequence/duplicate/swapped/dropped/foreign Tick拒絕 fixed WU04 release。','Accepted F2-QUALIFICATION parents、PROJECTION_POLICY、OBSERVATION_RELEASE_POLICY、TEMPORAL_CONFIGURATION、DECISION_SCHEDULE、CALENDAR 與 SEMANTIC_TRACE exact schemas/bytes。')
r['contract_clause_pointer'].append(pointer(SHARED,[513,514],'AD01-09 OBSERVATION / SEQUENCE'))
r=add('I05',DEFERRED,'F3/F5 experiment/policy/result/attempt/evidence full identity。',[5,6,8,10], 'defer domain oracle；不以空metrics、fake outputs或placeholder Parents製造成功digest。SOURCE-BYTES expected envelope也不提供 resource semantic approval。','F3/F5 owner protocols、method、maturity、metric、policy/outcome、actual attempt receipts、semantic evidence 與 rights review 未提供。')
r['contract_clause_pointer'].append(pointer(SHARED,[515,520],'AD01-09 remaining domain schemas'))
r=add('I06',RELATION,'Native A / production Codec B / F3-F5 / IF05 / IF07 未執行。',[7,8,10], '本輪所有 runtime/conformance/Native replay NOT_RUN；IF-05/IF-07與Codec/F3/F5 execution NOT_AUTHORIZED。RUN / VALUE_AVAILABLE / SUPPORTED / SELECTED 不授予 ELIGIBLE，四項diagnostic scope旗標與disposition保留。')
r['source_ref']=[pointer(WEEKLY,[69,75],'WU04 _SCOPE'),pointer(UX,[139,143],'ratified no-promotion/deferred gates')]
r['contract_clause_pointer'].append(pointer(SHARED,[618,632],'AD01-11 two-channel gate'))

# Extra compact challenge cases, separate from the 58 mandatory named cases.
r=add('L01',REFUSE,'CanonicalPayload limit16777216、LP prefix越界。',[4], '16777217-byte requested P 拒絕 allocation之前；0-byte P也拒絕。界內大小只是 length predicate，不保證 schema/type有效。無16MiB fixture/digest。')
art(r,'over_limit_prefix',bytes.fromhex('0000000001000001'),'INPUT')
r['components']['stimulus_recipe']='D/S合法；宣告 P length16777217且不配置body。只測 specification allocation/length predicate，非完整 malformed sample 的 product result。'
r=add('L02',REFUSE,'Record depth≤64，超過64拒絕。',[1], '65個巢狀 records（root亦為record）超過 bound；不 truncation，不成功digest。root depth起算慣例尚需 future codec邊界決策，本例刻意用66層以在0/1起算均超限。')
r['components']['stimulus_recipe']='66 nested records under grammar component: repeat {"a": 66 times + "x" + } 66 times; schema-free length/depth stimulus only'
r['contract_clause_pointer'].append(pointer(SHARED,[441,441],'AD01-07 common bounds'))
r=add('L03',REFUSE,'Array limit4096。',[1,9], '4097 items 拒絕；4096只滿足 collection bound，仍須 domain schema、membership/rights。無大fixture/digest。')
r['components']['stimulus_recipe']='JSON array with 4097 literal "a" items; no fixture allocation; no registered domain asserted'
r['contract_clause_pointer'].append(pointer(SHARED,[441,441],'AD01-07 common bounds'))
r=add('L04',REFUSE,'Role IDs/versions與 D/S bound128 bytes。',[1,4], 'ASCII role ID/version129 bytes拒絕；D/S length0/129拒絕。exact registry tuple仍另外必須匹配；無成功digest。')
r['components']['stimulus_recipes']=['ASCII A repeated129 for a role ID/version', 'empty D/S', 'ASCII A repeated129 D/S']
r['contract_clause_pointer'].append(pointer(SHARED,[528,528],'AD01-09 Text bounds'))
r=add('L05',REFUSE,'foreign/stale/dangling parent、cycle 與 resource substitution。',[5,10], 'parent typed domain mismatch、stale/dangling/reordered chain、subject→own EVIDENCE cycle拒絕；unknown/unreviewed Resource schema拒絕 documented REF_UNAPPROVED_RESOURCE_SCHEMA。僅 specification，不捏造 accepted graph/digest。')
r['components']['stimuli']=['F2-OBSERVATION qualification_ref points to SOURCE-BYTES expected envelope','missing parent bytes','old parent pin after semantic mutation','subject→own EVIDENCE→subject cycle','NUMERIC_POLICY with foreign unreviewed resource_schema']
r['contract_clause_pointer'].append(pointer(SHARED,[549,549],'Resource schema refusal'))
r=add('L06',RELATION,'code drift、fresh attempt與 same deterministic content。',[6,8,10], '相關 Native code drift按M24使依賴qualification改變或block replay；無 relevant closure不可假設無關。M27/M28 fresh actual attempt/clock不改固定 deterministic RESULT，但新attempt receipt不同。此輪無實際reissue/result hash。')
r['contract_clause_pointer'].append(pointer(SHARED,[582,592],'AD01-10 M24/M27/M28/M34'))

V.sort(key=lambda r: (['S','J','F','B','T','I','L'].index(r['vector_id'][0]), int(r['vector_id'][1:])))
assert len(V)==64 and len({r['vector_id'] for r in V})==64
for r in V:
    dump(ROOT/'vectors'/r['vector_id']/'expected.json',r)
counts=dict(Counter(r['class'] for r in V))
dump(ROOT/'oracle_vectors.json', {'format':'ORACLE01_EVIDENCE_CONTAINER_v0.1','not_app_domain':True,'vectors':V})
dump(ROOT/'oracle_scope_register.json', {'format':'ORACLE01_EVIDENCE_CONTAINER_v0.1','not_app_domain':True,
    'task_id':'MVP-IF-03-ORACLE-01','required_named_cases':58,'extra_cases':6,'cases_total':64,
    'class_counts':counts,'complete_positive_digests':8,'freeze_status':'PENDING_INDEPENDENT_REVIEW',
    'independent_review':'NOT_RUN','codec_conformance_tests':'NOT_RUN',
    'vectors':[{'vector_id':r['vector_id'],'class':r['class'],'status':r['status'],
                'blocked_prerequisite':r['blocked_prerequisite'],'expected_record':'vectors/'+r['vector_id']+'/expected.json'} for r in V]})
dump(ROOT/'vector_case_matrix.json', {'format':'ORACLE01_EVIDENCE_CONTAINER_v0.1','required_named_cases':58,'cases_total':64,
    'case_rows':[{'vector_id':r['vector_id'],'class':r['class'],'input_description':r['input_description'],
                 'contract_clause_pointer':r['contract_clause_pointer'],'source_ref':r['source_ref'],
                 'expected_relation_or_refusal':r['expected_relation_or_refusal'],'status':r['status'],
                 'blocked_prerequisite':r['blocked_prerequisite']} for r in V]})
print('AUTHORED_CASES=64 REQUIRED=58 EXTRA=6')
print('CLASS_COUNTS='+json.dumps(counts,sort_keys=True))
