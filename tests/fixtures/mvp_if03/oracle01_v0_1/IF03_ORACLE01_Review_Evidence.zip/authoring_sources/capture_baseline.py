"""Allowlisted read-only source capture, never import or execute repository modules."""
import hashlib
import json
import os
import platform
import stat
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
REPO = Path('/home/rooki/projects/pit-research-lab-mvp')
HEAD = '9ade777ac03052231088a91ef9849c5a506da184'
PATHS = [
    'docs/mvp/v1.0/shared-interface-contract-v0.1.md',
    'docs/mvp/v1.0/ux-adr-01-temporal-execution-contract-v0.1.md',
    'src/pit_research_lab/mvp/f2/synthetic_contracts.py',
    'src/pit_research_lab/mvp/f2/weekly_sequence.py',
    'tests/unit/mvp_f2/test_weekly_sequence.py',
]
PINS = [(140871, '66bef5b0bb8240214ec8ea14c3c94c8748e2944270883c56de3ae7f27355428b'),
        (23544, 'abb04bba20ce8640c38b2406aa662ae86ff3d6df892343b2e6d780c3073c01db')]
receipts = []
def git(*args):
    command = ['git', '--no-optional-locks', '-C', str(REPO), *args]
    result = subprocess.run(command, capture_output=True, text=True,
                            env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}, check=True)
    receipts.append({'argv': command, 'exit_code': result.returncode,
                     'stdout': result.stdout, 'stderr': result.stderr})
    return result.stdout.rstrip('\n')

top, branch, head, status = git('rev-parse', '--show-toplevel'), git('branch', '--show-current'), git('rev-parse', 'HEAD'), git('status', '--porcelain=v1', '--untracked-files=all')
assert (top, branch, head, status) == (str(REPO), 'main', HEAD, ''), 'ORACLE01_PREFLIGHT_BLOCKED'
remote, fetched = git('rev-parse', 'origin/main'), git('rev-parse', 'FETCH_HEAD')
assert remote == fetched == HEAD, 'ORACLE01_PREFLIGHT_BLOCKED'
rows = []
for i, rel in enumerate(PATHS):
    path = REPO / rel
    for parent in [path, *path.parents]:
        if parent == REPO.parent:
            break
        assert not parent.is_symlink()
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    body = path.read_bytes()
    pin = (len(body), hashlib.sha256(body).hexdigest())
    if i < 2:
        assert pin == PINS[i], ('ORACLE01_PREFLIGHT_BLOCKED', rel, pin)
    blob = git('rev-parse', HEAD + ':' + rel)
    local_blob = hashlib.sha1(b'blob ' + str(len(body)).encode('ascii') + b'\0' + body).hexdigest()
    assert blob == local_blob
    target = OUT / 'source_snapshots' / (rel + '.txt')
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as f:
        f.write(body)
    rows.append({'repo_path': rel, 'commit': HEAD, 'git_blob_sha1': blob,
                 'raw_byte_length': pin[0], 'raw_sha256': pin[1],
                 'snapshot': target.relative_to(OUT).as_posix(),
                 'source_kind': 'READ_ONLY_CONTRACT_OR_ASSERTION_NOT_EXECUTED'})
inventory = {
    'task_id': 'MVP-IF-03-ORACLE-01', 'head': head, 'branch': branch, 'top_level': top,
    'repo_dirty_before': False, 'status_before_porcelain': status,
    'origin_main': remote, 'fetch_head': fetched, 'remote_status': 'VERIFIED_SCOPED_FETCH',
    'contract_pin_status': 'PASS', 'sources': rows,
    'optional_WU01_anchor': 'NOT_READ_NOT_USED',
    'authorization_amendment': {'exact_user_text': 'I authorize you to access formal root',
        'applied_scope': 'Git metadata required by approved Academic checkout only; no Formal source/runtime inspection',
        'previous_blocked_package': '/tmp/mvp-if03-oracle01-20261114T035318Z-boundary-stop',
        'scoped_fetch_observed': {'argv': ['git', 'fetch', '--no-tags', '--no-recurse-submodules', 'origin', 'main'],
            'cwd': str(REPO), 'exit_code': 0,
            'tool_output': 'From github.com:EricCheng24/pit-research-lab\n * branch            main       -> FETCH_HEAD\n',
            'mechanism': 'sandbox require_escalated after authorized metadata write was denied in sandbox'}},
    'formal_source_or_runtime_access': 'NONE; Git metadata exception only',
    'no_repo_modules_imported': True, 'interpreter': platform.python_version(),
    'receipts': receipts,
}
(OUT / 'source_contract_inventory.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
print('BASELINE_PASS sources=5 contract_pins=2 remote=VERIFIED_SCOPED_FETCH')
