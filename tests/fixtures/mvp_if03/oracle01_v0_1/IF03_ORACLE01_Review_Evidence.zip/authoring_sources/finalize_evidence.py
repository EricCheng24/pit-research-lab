"""Traditional-Chinese documentation and finite evidence schema; no repository writes."""
import hashlib
import json
import platform
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
V=json.loads((ROOT/'oracle_vectors.json').read_text())['vectors']
INV=json.loads((ROOT/'source_contract_inventory.json').read_text())
SCOPE=json.loads((ROOT/'oracle_scope_register.json').read_text())
CHECK=json.loads((ROOT/'author_self_check.json').read_text())
assert CHECK['author_self_check']=='PASS'
byid={r['vector_id']:r for r in V}
def write(name,text):
    path=ROOT/name
    with path.open('x',encoding='utf-8') as f:f.write(text)
def jwrite(name,obj):write(name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def esc(text):return text.replace('|','\\|').replace('\n',' ')
def clauses(r):return ', '.join(p['clause']+' L'+str(p['lines'][0])+('–'+str(p['lines'][1]) if p['lines'][0]!=p['lines'][1] else '') for p in r['contract_clause_pointer'])
def matrix(rows):
    text='|ID|Class|Input / 期望|Clause|Status / prerequisite|\n|---|---|---|---|---|\n'
    for r in rows:
        text+='|'+r['vector_id']+'|'+r['class']+'|'+esc(r['input_description']+' '+r['expected_relation_or_refusal'])+'|'+esc(clauses(r))+'|'+esc(r['status']+'；'+(r['blocked_prerequisite'] or '無此 case 的額外 resource prerequisite'))+'|\n'
    return text
counts='|Class|Cases|\n|---|---:|\n'+''.join('|'+k+'|'+str(n)+'|\n' for k,n in sorted(SCOPE['class_counts'].items()))
sources='|Source path|Blob SHA-1|Bytes|Raw SHA-256|\n|---|---|---:|---|\n'+''.join('|'+s['repo_path']+'|'+s['git_blob_sha1']+'|'+str(s['raw_byte_length'])+'|'+s['raw_sha256']+'|\n' for s in INV['sources'])
bodytable='|ID|Raw hex|Raw bytes|P bytes|Frame bytes|BODY SHA-256|FRAME SHA-256|Artifacts|\n|---|---|---:|---:|---:|---|---|---|\n'
for r in V:
    if r['class']=='VALID_COMPLETE_DOMAIN':
        vid=r['vector_id'];bodytable+='|'+vid+'|'+(r['exact_input_bytes_hex']['raw_body'] or '(empty)')+'|'+str(r['raw_body_byte_length'])+'|187|281|'+r['expected_raw_sha256']+'|'+r['expected_frame_sha256']+'|[full derivation](vectors/'+vid+'/derivation.md), [raw](vectors/'+vid+'/raw_body.bin), [payload](vectors/'+vid+'/canonical_payload.bin), [frame](vectors/'+vid+'/frame.bin)|\n'

# Strict container keys are finite. This metadata schema is not canonical App JSON.
allkeys=set().union(*(r.keys() for r in V))
required=['vector_id','vector_version','class','contract_clause_pointer','source_ref','input_description',
          'exact_input_bytes_hex','exact_scalar_or_payload_bytes_hex','exact_frame_bytes_hex',
          'expected_raw_sha256','expected_frame_sha256','expected_envelope_fields','expected_relation_or_refusal',
          'status','blocked_prerequisite','authoring_method','limitations','review_state','artifacts','components']
types={k:{'type':'string'} for k in allkeys}
for k in ['exact_input_bytes_hex','exact_scalar_or_payload_bytes_hex','components','hash_method']:types[k]={'type':'object'}
for k in ['contract_clause_pointer','limitations','artifacts','frame_dissection']:types[k]={'type':'array'}
for k in ['raw_body_byte_length','canonical_payload_byte_length','frame_byte_length']:types[k]={'type':'integer','minimum':0}
for k in ['exact_frame_bytes_hex','expected_raw_sha256','expected_frame_sha256','blocked_prerequisite']:types[k]={'type':['string','null']}
types['expected_envelope_fields']={'type':['object','null']}
types['source_ref']={'oneOf':[{'const':'SELF_CONTAINED_SYNTHETIC'},{'type':'array','minItems':1}]}
types['class']={'enum':list(sorted(SCOPE['class_counts']))}
types['review_state']={'const':'PENDING_INDEPENDENT_REVIEW'}
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:oracle01:evidence-container:vector:v0.1',
        'title':'Oracle evidence vector (not an App canonical domain)','type':'object','additionalProperties':False,
        'required':required,'properties':dict(sorted(types.items()))}
jwrite('oracle_vector.schema.json',schema)
for r in V:assert set(r)<=allkeys and set(required)<=r.keys()
write('oracle_evidence_container_format.md','''# ORACLE01_EVIDENCE_CONTAINER_v0.1

此 JSON 是外部 evidence metadata，**不是 CanonicalPayload、Domain 或 Resource schema**；JSON numbers/null、pretty printing 與中文可用於此容器，不可套用成 App payload。`oracle_vector.schema.json` 定義有限允許 keys、required keys 與 top-level types；未宣稱執行第三方 JSON Schema validator。

`oracle_vectors.json.vectors[]` 與每個 `vectors/<ID>/expected.json` 必須逐 JSON value 相同。`oracle_scope_register.json.vectors[]` 只做一對一索引；matrix 是同一組64 cases的審查投影，並非另一批測試。每 row 僅一個 class；64中58為需求ID、L01..L06為補充，不能用substimuli增加計數。

`exact_input_bytes_hex`、`exact_scalar_or_payload_bytes_hex` 是 artifact-name→完整lowercase hex 的 maps；空body用空hex字串。`exact_frame_bytes_hex` 只有 VALID_COMPLETE_DOMAIN 可非null；invalid frame stimuli只在 input map，不能被當成 expected成功frame。`expected_raw_sha256`、`expected_frame_sha256`、`expected_envelope_fields` 限完整SOURCE-BYTES；其他case必為null。`expected_payload_sha256_audit_only` 只是P檔audit hash，不能代替frame digest。Artifact manifest/checksums 的 SHA-256 亦只是 package integrity。

`artifacts[]` 記錄 name、role（INPUT / SCALAR_OR_PAYLOAD / FRAMING_COMPONENT / FRAME）、bin、hex、byte_length；UTF-8可解碼則加 `utf8_file`（內容完全相同，無附加換行），否則 `utf8_rendering=UNDEFINED_INVALID_UTF8`。不可把任一 .utf8.txt 當成有lossy replacement的preview。B01空 `.bin` 與空 rendering均刻意保留。

`contract_clause_pointer[]` 與 repository-based `source_ref[]` 使用 repo_path、commit、git_blob_sha1、lines=[start,end]（含端點）、clause。SELF_CONTAINED_SYNTHETIC 的cases亦有已pin contract pointers；各來源的完整raw snapshot與inventory可用於不連線逐行核對。T01..T04引用的是已提交 assertions及literal WU04 pins，不是本輪重新執行／重新驗證Native source bodies。

`components` 為 case-specific documentary資料，內部labels不是Domain/Resource IDs；recipes指定未物化的大型刺激，不表示執行或接受。拒絕類別採敘述，僅 REF_CYCLE 與 REF_UNAPPROVED_RESOURCE_SCHEMA 引用實際contract既有code，不發明實作error constants。Mixed-outcome challenge如S14只有一個primary class BLOCKED_BY_RESOURCE_SCHEMA，component agreement/mismatch規格保留在同row；不強行產生完整positive。

status 是本 evidence container 的 authoring disposition，不是 App lifecycle。review_state 全為 PENDING_INDEPENDENT_REVIEW；freeze_status同值，無 FROZEN。分類、keys、scope counts、逐檔hex與binary一致性由作者self-check檢查；這不等於schema語義/independent review/product Codec測試。
''')
write('IF03_ORACLE01_Scope_and_Blocker_Register.md',f'''# Oracle-01 Scope and Blocker Register

`ORACLE_AUTHORING_READY_FOR_INDEPENDENT_REVIEW`；64 cases（58 mandatory +6 extra）。八個complete候選，只有 SOURCE-BYTES；沒有issued resource/reference。所有 review_state / freeze_status=`PENDING_INDEPENDENT_REVIEW`。

{counts}

Resource positive objects：S12 Decimal、S14 FixedRatio6、T06 TimeRecord sensitivity、I03 F2-QUALIFICATION、I04 F2-OBSERVATION / TEMPORAL-SEQUENCE 共5 blocked；I05 remaining F3/F5/EVIDENCE domains 1 deferred。這些是有理由的完整case dispositions，不影響bounded authoring交付，亦不是full-domain closure。

{matrix(V)}

分組計數：O01 S01..S14=14；O02 J01..J12=12；O03 F01..F12=12；O04 B01..B08=8；O05 T01..T06=6；O06 I01..I06=6；supplement L01..L06=6。Framing component4需獨立計數；refusal21不等於執行21個Codec rejection tests。

欄位與bytes解讀見 oracle_evidence_container_format.md。所有clause pointers以inventory固定commit/blob為準，RT01-03覆蓋ADOPT歷史candidate字樣；不把舊字樣當veto，也不把ratification當freeze。
''')

write('IF03_ORACLE01_Independent_Review_HandOff.md',f'''# Independent Oracle Review HandOff

唯一下一個authority event：`INDEPENDENT_REVIEW_OF_EXACT_ORACLE_BYTES`。本作者並非此包的 Independent Reviewer；`INDEPENDENT_REVIEW=NOT_RUN`。不得先freeze或實作Codec。

1. 先驗證 ZIP SHA-256（ZIP外 SHA256SUMS）、CRC、manifest精確coverage與每個member的bytes/SHA；拒絕absolute/..、duplicates、encrypted/link members。MANIFEST不含自身；SHA256SUMS和delivery receipt在ZIP外。ZIP內所有其他檔都須被MANIFEST涵蓋。
2. 確認base `{INV['head']}`、五個source snapshots raw SHA與Git blob，兩份contract pins和原始lines。查看authorization amendment：Owner後續文字授權Formal root，本輪僅用於Academic checkout shared Git metadata；Formal source/runtime未探查。先前blocked包留在原位置，不能與此包混用。
3. 必須直接讀取B02、B03、B04、B06、B08的raw_body.bin：41 / 00 / c3a9 / ff / 42。從CAN-01/02、AD01-09三個fields與原body重新寫自己的payload，不複製作者payload/frame，不rerun author_cases.py作為唯一review。
4. Fresh preimages：D=`PITLAB/ACADEMIC/SOURCE-BYTES/candidate-v0.1`、S=`source-bytes-candidate-v0.1`。根據自己算的byte lengths組三個LP64BE段；逐byte比對作者frame，再以standard primitive計算fresh SHA-256。B01/B05/B07也要確認，B01尤其挑戰UInt64 zero、SOURCE-BYTES無額外非空body限制；P必須非空，不能混淆body/P。
5. 所有8個SOURCE-BYTES同為P187/frame281，但不要先信這兩個數；手算literal片段46+1+18+64+58。prefix offsets0/51/86、data8/59/94，end281。檢查expected envelope精確六欄與payload-only length187，profile在P內且OWN digest/envelope/locator在外。B01空body與B06 opaque ff不代表CanonicalPayload可invalid UTF-8。
6. Sensitive fragments：S01/S02/S03/S04/S06、S07 Boolean、J01 quote/backslash、J02 NFC/NFD、J03中文、J04全部所列controls、J12 content-byte界線。檢查Int overflow、+1/01/-0、bool↔int、Decimal scale保存及FixedRatio6 policy缺席。S12/S14不得因component bytes而發完整resource identity。
7. 主動challenge duplicate-before-map、null/omission/tag substitution、short escapes、BOM/surrogates、swapped domain/schema、profile只在Envelope、malformed/trailing frame、uppercase digest、self-envelope、BODY/FRAME confusion、foreign/stale/dangling parent與cycle。Refusal只有specification，production Codec NOT_RUN；不要把作者self-check當已觀察拒絕。
8. 全64 rows逐一對clause而非只對counter；必須確認58 mandatory均涵蓋其contrast。T01 AT非BEFORE、T02 t3+1s、T03 D2同值不同context與原四pins、T04 W03非第五Tick；無reviewed TIMEZONE_RULES就不能發TimeRecord/F2 positive。無policy/resource schema亦不准補placeholder refs。
9. 查candidate_revision_log.json：R1僅修手算片段長度說明44→46/60→58並增加J12 quoted-unit artifact；8個positive raw/P/frame/hash完全不變。原執行helper保留為author_cases.executed-v0.py，其SHA對應author_cases.receipt；更新template未重跑。不能將此作者修正當Independent Review通過。
10. Discrepancies用P0/P1/P2分級，給固定commit/path/line、實際observed byte offset、expected vs observed與最小remediation；獨立提供verdict。只有全部充分justify才可建議Owner對**limited scope exact manifest/pins**另行Freeze，不得替Owner批准、Git integrate、發reference或接受Replay/PIT/IF05/IF07。

最低可重建材料：五份原始source snapshots、完整literal raw body/bin/hex、每個B的full payload UTF-8與frame hex、逐段offset derivation、expected envelope fields。metadata numeric/null不是App encoding。

外部需要的hash command可用reviewer自己寫的standard-library程式或 `sha256sum <fresh-frame-file>`。作者現有primitive是在Python {platform.python_version()}，輸入explicit *.bin，實際argv/stdout/stderr與stdout checksum見execution/*.receipt.json；這只證明作者工具計算，未取代reviewer重建。
''')

cantable='''|Clause|固定source lines|本輪coverage / limitation|
|---|---|---|
|CAN-01|455–456|S/J fragments、B exact ASCII payload；J07..J11 documentary refusals；L02/L03/L04 compact bounds|
|CAN-02|457–458|S01..S11 exact fragment/refusal；S12/S14 full resource positive blocked；S13 refusal；B typed UInt64|
|CAN-03|459–460|T01..T04 relation、T05 refusal、T06 blocked；無host tzdb或full TimeRecord hash|
|CAN-04|461–462|F01..F04 LP components、B01..B08 complete frames、F05/F06/F09 relations、其他F documentary拒絕、L01 bounds|
|CAN-05|463–464|B expected六欄Envelope；S12/S14/T06/I03/I04 resource gates；F11/L05 self/parent拒絕|
|CAN-06|465–466|I02/L06 local/code provenance relation；I03完整qualification blocked，無observed code執行聲稱|
|CAN-07|467–468|J09 tag/null refusal、I04不可empty success、I06 invocation與PIT分離；無fabricated first failure|
|CAN-08|469–470|I05 domains deferred、I06 NOT_RUN、L06 fresh attempt relation；無actual new execution|
|CAN-09|471–472|J06 array order、T04 annotation、I04 fixed profile拒絕；無完整sequence graph/digest|
|CAN-10|473–474|F07/F08/F12/L05 strict negotiation、I02 local identity分離、I05 defer；無migration/TypeScript parity|
'''
report=f'''# IF03_ORACLE01 Authoring Report

## 1. Verdict

`ORACLE_AUTHORING_READY_FOR_INDEPENDENT_REVIEW`。八個 independently authored bounded synthetic SOURCE-BYTES **candidate expected**完整向量；64 named specification cases（58 mandatory+6 extra）。所有review_state、freeze_status均`PENDING_INDEPENDENT_REVIEW`。獨立性是本輪authoring未使用future/product Codec與repo serializer；不是外部review或實作驗收。

## 2. Source and Baseline Proof

Academic repo `{INV['top_level']}`；branch `main`；HEAD、origin/main、FETCH_HEAD均 `{INV['head']}`。Scoped fetch已成功（no tags/no recurse-submodules），Git receipts在source_contract_inventory.json。開始與結束porcelain皆空；REPO_DIRTY_BEFORE=false、REPO_DIRTY_AFTER=false。兩份contract pin exact PASS；五個原始檔與HEAD blob相等。沒有read optional72,800-byte anchor、沒有WU03-A packet複本。

{sources}

所有表列檔案以完整raw bytes另存source_snapshots/*.txt，commit/blob/byte/SHA固定；條款來源CAN-01..10、AD01-08/09/10/11、RT01-01..05與UX ADOPT/RATIFY已閱讀。WU01 input_bytes/payload_pin L209–236只讀；weekly_sequence.py四個tick pins L63–68、flags L69–75、public __all__ L27與run_weekly_sequence均未執行。test_weekly_sequence.py L38–43/L295–382讀取為committed assertions，不當作本輪Native驗證。

原preflight fetch因shared Git metadata指到Formal root而停止，舊blocked包保留`/tmp/mvp-if03-oracle01-20261114T035318Z-boundary-stop`。Owner後續明確說 `I authorize you to access formal root`；本輪只對Academic checkout必要Git metadata使用該授權與sandbox escalation完成fetch。沒有列舉／讀取Formal source、runtime、credentials或其他sibling worktrees。不能宣稱零Formal-root metadata access；source/runtime保護仍維持。沒有Git stage/commit/push/PR/branch切換，fetch只更新授權metadata；無repository source/test/config/cache輸出。

RT01 L668/L720–739與UX L131–143是後來RATIFIED_EXACT overlay；ADOPT歷史CANDIDATE_FOR_OWNER_RATIFICATION不是veto。Ratification沒有freeze/full-domain/resource/runtime授權；本輪依user另授權bounded authoring。

## 3. Scope Accounting

{counts}

完整digests=8；scalar fragment cases=14；framing component cases=4；refusal specification cases=21；relational assertion cases=11；blocked5+deferred1=6；合計64。Substimuli不增加case數。O01=14、O02=12、O03=12、O04=8、O05=6、O06=6；L01..L06=6補充。逐case精確source pointers、status與disposition如下，亦與Scope Register/JSON相符。

{matrix(V)}

## 4. CAN-01..10 Clause Matrix

{cantable}

全部為expected specification/fragment coverage，不是64個executed product conformance tests；AUTHOR_SELF_CHECK的{CHECK['checks_count']}個內部assertions亦不是產品測試數。

## 5. SOURCE-BYTES Golden Candidate Table

{bodytable}

B01允許原因：CAN-02 UInt64範圍含0，AD01-09 SOURCE-BYTES沒有額外body非空限制；CAN-04的payload length>=1約束P，不約束raw body。本例P187，不用空P冒充。B06允許原因：SOURCE-BYTES欄位取exact raw body bytes/hash，UTF-8規則約束canonical payload；opaque ff不解碼，P仍合法UTF-8。請Independent Reviewer明確challenge兩項解讀。

每個B有raw_body.bin、canonical_payload.bin、frame.bin與全hex；可解碼的artifact另有逐bytes相同UTF-8檔。expected.json含六欄expected envelope；derivation.md含raw hex、手數length、完整P文字與hex、完整frame hex與hash。B02→B08與B04→B05在sample上raw SHA、P、frame SHA均不同。SHA-256 collision resistance是integrity假設，未聲稱數學無collision。

共同claim：`CONTENT_INTEGRITY_ONLY / NOT_SOURCE_AUTHENTICATION / NOT_PIT_ADMISSION`。沒有Resource schema批准、issuer/resolver capability或admitted SnapshotReference。

## 6. Frame Dissection & ReferenceEnvelope Rules

D是ASCII43 bytes，S是ASCII27 bytes。LP(D) prefix[0,8)=000000000000002b，D[8,51)；LP(S) prefix[51,59)=000000000000001b，S[59,86)；LP(P) prefix[86,94)=00000000000000bb，P[94,281)。end281，無trailing data。總長24+43+27+187=281。

P literal片段長度46+raw-length一位數1+18+raw-sha64+profile suffix58=187。精確鍵序body_byte_length、body_sha256、canonical_profile_version；UInt64內層type、value。Profile `typed-json-candidate-v0.1`在P內；Envelope長度typed UInt64187，不是281。Envelope精確domain_tag/object_schema_version/canonical_profile_version/digest_algorithm/canonical_payload_byte_length/digest_hex，OWN envelope/digest/locator不在P；standalone SOURCE-BYTES不需要ParentRef。

BODY SHA=SHA256(raw_body.bin)；FRAME SHA=SHA256(frame.bin)；payload SHA僅以expected_payload_sha256_audit_only記錄。Unsupported D/S toy只是F07 invalid input；沒有toy digest或新SCALAR domain。

## 7. Negative/Mutation and Blocked Case Matrix

完整矩陣見section3與Scope Register。S08..S11/S13、J07..J11、F07/F08/F10..F12、T05、L01..L05共21 documentary refusals；沒有聲稱產品已返回error。既有REF_CYCLE（AD01-08 L489）、REF_UNAPPROVED_RESOURCE_SCHEMA（AD01-09 L549）可引用，其餘用拒絕category敘述，不創造error constants。

S12/S14 Numeric policy resource、T06 timezone/origin resources、I03 qualification closure、I04 observation/sequence parents/policies blocked；I05 F3/F5/EVIDENCE future domain deferred。無placeholder refs hash。T05混合刺激全部主張不可成功：格式不合法或unpinned rules拒絕；不使用host timezone資料代替。

WU04 t1 strict AT非BEFORE、t3+1s、t2/t3 D2相同但context不同、W03非fifth tick均是關係cases，源於pinned文字/assertions，不重新生成WU01/A05或完整F2 canonical hashes。S3/A04/A05/B03既有local preimages保持分離；diagnostic_only=True、admission_eligible=False、NOT_TRUSTED_PIT_EVIDENCE、NOT_ESTABLISHED、INTEGRATED_PROVISIONAL不升級。

## 8. Oracle Independence Assessment

Author是本次Codex assistant。原raw samples以explicit hex literal獨立寫出；S/J strings與numeric records由各case literal/hex建構，沒有generic serializer。SOURCE-BYTES只用明列的三fields literal拼接，D/S與LP64BE prefix亦固定可檢查；JSON dumps只寫外部metadata，未用來產生canonical payload。沒有import repo、canonical_codec、Native owner或WU01 input_bytes。

Python {platform.python_version()} standard library hashlib對**已寫出的**raw_body.bin/frame.bin計算SHA；stdout列完整八組BODY/FRAME hashes。實際command、interpreter、source SHA、stdout/stderr與checksum見execution/author_cases.receipt.json；primitive計算是工具結果，不是心算。author_cases.executed-v0.py保留真正首次執行source；更新template author_cases.py未重跑，R1 helper已對candidate套用同樣修正。

R1修正手算片段說明44→46/60→58（sum187未變），並補J12 exact quoted-unit bytes。8組raw/P/frame與digests均未改。candidate_revision_log.json記前後檔SHA；不涉及normative rule變動。self_check.py獨立於author helper，以strict parsing、fixed-layout regex、literal constants、segment parsing核對；結果PASS，只是AUTHOR_SELF_CHECK_ONLY。

## 9. Unresolved Contract Ambiguities

此bounded八組SOURCE-BYTES沒有發現需要改contract的blocking ambiguity。B01/B06的適用規則與推理已明列供challenge。Record depth的root起算慣例未在文件另給可執行算法；L02用66層以在常見0/1起算皆超64，不聲稱解決未來64/65精準邊界；future Codec先由contract review確認計數再做該正向邊界。不是本輪默改規則。

外部Resource bodies/schemas與time/policy/rights並非可自行補齊的ambiguity；affected positives明確blocked。沒有owner-policy attestation、runtime acceptance或全域identity equivalence。

## 10. Deferred Gates

TIMEZONE_RULES、NUMERIC_POLICY、完整F2/F3/F5及EVIDENCE resources/parents、IF-04 capabilities、IF-05 predicates、IF-07 real-source rights/history、Native Replay Channel A、production Codec/Channel B、TypeScript parity、consumer handoff、Golden Freeze與Git integration均未完成／未授權。本輪Native/pytest/Makefile/services/database/real providers完全NOT_RUN，無新PIT claim。

## 11. Artifact Manifest and Exact Delivery Paths

Root `{ROOT}`；report `{ROOT}/IF03_ORACLE01_Authoring_Report.md`；scope `{ROOT}/oracle_scope_register.json`；handoff `{ROOT}/IF03_ORACLE01_Independent_Review_HandOff.md`；ZIP `{ROOT}/IF03_ORACLE01_Review_Evidence.zip`。

MANIFEST.json列ZIP中除其自身外所有member的排序relative path、byte_length與SHA-256；沒有self hash。SHA256SUMS在ZIP外涵蓋所有ZIP members（含manifest）與ZIP本體；package_validation.json和packaging stdout/stderr為ZIP外delivery receipts，避免archive自hash循環。ZIP SHA-256的實際值記在該外部receipt、SHA256SUMS與最終交付訊息；不嵌入會改變自身ZIP hash的內部report。

Packager會驗證CRC、完整manifest coverage、member byte/SHA、safe paths、無duplicate/encryption/symlink/hardlink，然後獨立delivery script再次核對，任一不合格不handoff。檔案皆外部regular single-link copies，source snapshots不是hardlinks；無下載依賴。Reviewer步驟與fresh preimage要求見獨立handoff。

## 12. Explicit Next Authority Request

`INDEPENDENT_REVIEW_OF_EXACT_ORACLE_BYTES` **only**。請另一位reviewer核實完整bytes、refusal及blocker，再另交獨立verdict。freeze_status=`PENDING_INDEPENDENT_REVIEW`；本輪不要求Commit/Push/Merge或Codec implementation，亦不宣稱IF03_GOLDEN_ORACLE_FROZEN、IF03_DOMAIN_IDENTITY_ACCEPTED、CANONICAL_CODEC_ACCEPTED、REPLAY_ACCEPTED、PIT_VERIFIED、F2_HANDOFF_ACCEPTED或F3_F5_READY。
'''
write('IF03_ORACLE01_Authoring_Report.md',report)

# Preserve observed tool-returned output for the two bootstrap/correction stages.
for name,stdout in [('capture_baseline','BASELINE_PASS sources=5 contract_pins=2 remote=VERIFIED_SCOPED_FETCH\n'),('revise_candidates','CANDIDATE_REVISION_R1_COMPLETE positive_preimages_unchanged=True\n')]:
    write('execution/'+name+'.stdout.txt',stdout);write('execution/'+name+'.stderr.txt','')
    src=ROOT/'authoring_sources'/(name+'.py')
    jwrite('execution/'+name+'.receipt.json',{'argv':['python3','-B',str(src)],'cwd':'/tmp','exit_code':0,
        'interpreter':'Python '+platform.python_version(),'capture_kind':'TRANSCRIBED_FROM_OBSERVED_EXEC_COMMAND_OUTPUT (combined stream; successful output shown, no stderr content observed)',
        'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
        'stdout_file':'execution/'+name+'.stdout.txt','stdout_sha256':hashlib.sha256(stdout.encode()).hexdigest(),
        'stderr_file':'execution/'+name+'.stderr.txt','stderr_sha256':hashlib.sha256(b'').hexdigest()})
transcript='''MVP-IF-03-ORACLE-01 author execution transcript
Language: zh-TW reports; exact commands/identifiers preserved.
No product/Native/pytest/Makefile/service/database execution.
Initial boundary stop was preserved in the earlier separate blocked package.
User amendment: I authorize you to access formal root
Applied only to Git metadata of the Academic linked checkout.
Scoped fetch: git fetch --no-tags --no-recurse-submodules origin main
Sandbox failed open FETCH_HEAD read-only; rerun require_escalated after authorization succeeded exit0.
From github.com:EricCheng24/pit-research-lab
 * branch            main       -> FETCH_HEAD
Python: '''+platform.python_version()+''' (standard library only; -B)
Baseline Git argv/stdout/stderr and exact pins are recorded in source_contract_inventory.json.
'''
for name in ['capture_baseline','author_cases','revise_candidates','self_check']:
    receipt=json.loads((ROOT/'execution'/(name+'.receipt.json')).read_text())
    transcript+='\nSTAGE '+name+'\n'+json.dumps(receipt,ensure_ascii=False,indent=2)+'\nSTDOUT:\n'+(ROOT/'execution'/(name+'.stdout.txt')).read_text()+'STDERR:\n'+(ROOT/'execution'/(name+'.stderr.txt')).read_text()
transcript+='\nFinal documentation command: python3 -B '+str(Path(__file__))+'\nExpected stdout: DOCUMENTATION_COMPLETE\nPackaging/validation commands and actual stdout/stderr are separate external delivery receipts; packager source included.\n'
write('author_execution_transcript.txt',transcript)
print('DOCUMENTATION_COMPLETE')
