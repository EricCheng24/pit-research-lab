"""Finalize and validate ZIP package; no repository access and no App codec."""
import hashlib
import json
import platform
import stat
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

# Documentation-only source-line transcription fix, discovered before packaging.
p=ROOT/'IF03_ORACLE01_Authoring_Report.md'
before=p.read_bytes()
after=before.replace(b'public __all__ L27',b'public __all__ L32')
assert after!=before
p.write_bytes(after)
log=json.loads((ROOT/'candidate_revision_log.json').read_text())
log['documentation_revision_R2']={'reason':'Correct observed weekly_sequence.py public __all__ source pointer L27→L32; actual run_weekly_sequence at L514. No vector changes.',
    'report_before_sha256':hashlib.sha256(before).hexdigest(),'report_after_sha256':hashlib.sha256(after).hexdigest(),
    'applied_by':'authoring_sources/package_evidence.py'}
(ROOT/'candidate_revision_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'author_execution_transcript.txt').open('a') as f:
    f.write('\nR2 documentation correction: public __all__ pointer L27→L32; no vectors changed.\n'
            'Packaging command: python3 -B '+str(Path(__file__))+'\n'
            'Packaging actual stdout/stderr and their checksums are ZIP-external (packaging_stdout.txt, packaging_stderr.txt, package_validation.json).\n'
            'Delivery verification: python3 -B '+str(ROOT/'authoring_sources/validate_delivery.py')+'\n'
            'Both helpers are included; external receipts avoid archive self-hash cycles.\n')

# Integrity check all final vector metadata and registered top-level container schema.
vectors=json.loads((ROOT/'oracle_vectors.json').read_text())['vectors']
schema=json.loads((ROOT/'oracle_vector.schema.json').read_text())
for row in vectors:
    assert set(schema['required'])<=row.keys() and set(row)<=set(schema['properties'])
    assert json.loads((ROOT/'vectors'/row['vector_id']/'expected.json').read_text())==row
    for a in row['artifacts']:
        b=(ROOT/a['bin']).read_bytes()
        assert len(b)==a['byte_length'] and b==bytes.fromhex((ROOT/a['hex']).read_text())
        if 'utf8_file' in a:assert (ROOT/a['utf8_file']).read_bytes()==b

excluded={'MANIFEST.json','SHA256SUMS','IF03_ORACLE01_Review_Evidence.zip',
          'packaging_stdout.txt','packaging_stderr.txt','package_validation.json'}
files=[]
for path in ROOT.rglob('*'):
    info=path.lstat()
    assert not path.is_symlink()
    if stat.S_ISDIR(info.st_mode):continue
    assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
    assert path.suffix!='.pyc' and '__pycache__' not in path.parts
    if path.relative_to(ROOT).as_posix() not in excluded:files.append(path)
files.sort(key=lambda p:p.relative_to(ROOT).as_posix())
records=[{'path':p.relative_to(ROOT).as_posix(),'byte_length':p.stat().st_size,
          'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest={'format':'ORACLE01_PACKAGE_MANIFEST_v0.1','scope':'Every ZIP file except MANIFEST.json itself',
          'task_id':'MVP-IF-03-ORACLE-01','freeze_status':'PENDING_INDEPENDENT_REVIEW',
          'zip_external_files':sorted(excluded-{'MANIFEST.json','IF03_ORACLE01_Review_Evidence.zip'}),
          'files':records}
m=ROOT/'MANIFEST.json'
with m.open('x') as f:json.dump(manifest,f,ensure_ascii=False,indent=2);f.write('\n')
archive=ROOT/'IF03_ORACLE01_Review_Evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files+[m],key=lambda p:p.relative_to(ROOT).as_posix()):
        z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))
    assert set(z.namelist())=={'MANIFEST.json'}|{r['path'] for r in records}
    for i in z.infolist():
        p=Path(i.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
        assert not i.flag_bits&1 and stat.S_ISREG(i.external_attr>>16)
    for r in records:
        b=z.read(r['path'])
        assert len(b)==r['byte_length'] and hashlib.sha256(b).hexdigest()==r['sha256']
print('ZIP_CRC_MANIFEST_SAFE_PATHS=PASS')
print('ZIP_MEMBERS='+str(len(records)+1))
print('ZIP_BYTES='+str(archive.stat().st_size))
print('ZIP_SHA256='+hashlib.sha256(archive.read_bytes()).hexdigest())
