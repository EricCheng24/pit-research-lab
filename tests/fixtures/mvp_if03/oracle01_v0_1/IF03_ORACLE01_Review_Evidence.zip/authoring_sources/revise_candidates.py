"""Logged candidate-only transcription correction; original executed helper retained."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
changes=[]
for path in sorted((ROOT/'vectors').glob('B*/derivation.md')):
    before=path.read_bytes()
    text=before.decode().replace('=44 + 1 digit','=46 + 1 digit').replace('=60`；以實際文字逐 byte 核對為準（另見自檢）。','=58`；46+1+18+64+58=187。')
    assert text.encode()!=before
    path.write_text(text,encoding='utf-8')
    changes.append({'path':path.relative_to(ROOT).as_posix(),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
p=ROOT/'vectors/J12'
body=bytes.fromhex('22c3a922')
for suffix,data in [('.bin',body),('.hex',(body.hex()+'\n').encode()),('.utf8.txt',body)]:
    with (p/('quoted_unit'+suffix)).open('xb') as f:f.write(data)
vectors=json.loads((ROOT/'oracle_vectors.json').read_text())
j=next(r for r in vectors['vectors'] if r['vector_id']=='J12')
j['exact_scalar_or_payload_bytes_hex']['quoted_unit']=body.hex()
j['artifacts'].append({'name':'quoted_unit','role':'SCALAR_OR_PAYLOAD','bin':'vectors/J12/quoted_unit.bin','hex':'vectors/J12/quoted_unit.hex','byte_length':4,'utf8_file':'vectors/J12/quoted_unit.utf8.txt'})
for path,obj in [(ROOT/'oracle_vectors.json',vectors),(p/'expected.json',j)]:
    before=path.read_bytes();path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    changes.append({'path':path.relative_to(ROOT).as_posix(),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
log={'revision':'AUTHOR_CANDIDATE_TRANSCRIPTION_R1','reason':'Manual derivation prose split lengths corrected44→46/60→58; total187 and actual bytes unchanged. J12 exact quoted unit component added.',
     'normative_change':False,'positive_body_payload_frame_or_digest_changed':False,
     'original_executed_source':'authoring_sources/author_cases.executed-v0.py',
     'updated_template':'authoring_sources/author_cases.py (not rerun; equivalent corrections applied by this helper)',
     'changed_files':changes}
(ROOT/'candidate_revision_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n')
print('CANDIDATE_REVISION_R1_COMPLETE positive_preimages_unchanged=True')
