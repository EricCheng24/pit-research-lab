"""External subprocess receipt writer; never executes repository code."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
name=sys.argv[1]
assert name in {'author_cases','self_check','finalize_evidence'}
target=root/'authoring_sources'/(name+'.py')
argv=[sys.executable,'-B',str(target)]
result=subprocess.run(argv,cwd='/tmp',capture_output=True)
folder=root/'execution'
folder.mkdir(exist_ok=True)
for suffix,body in [('stdout',result.stdout),('stderr',result.stderr)]:
    with (folder/(name+'.'+suffix+'.txt')).open('xb') as f:f.write(body)
receipt={'argv':argv,'cwd':'/tmp','exit_code':result.returncode,
         'interpreter':sys.version,'script_raw_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
         'stdout_file':'execution/'+name+'.stdout.txt','stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
         'stderr_file':'execution/'+name+'.stderr.txt','stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
with (folder/(name+'.receipt.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(result.stdout.decode(),end='')
print(result.stderr.decode(),end='',file=sys.stderr)
raise SystemExit(result.returncode)
