"""AUTHOR_SELF_CHECK_ONLY. Literal-file/structural audit, not a product validator."""
import hashlib
import json
import os
import re
import stat
import subprocess
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
INV=json.loads((ROOT/'source_contract_inventory.json').read_text())
V=json.loads((ROOT/'oracle_vectors.json').read_text())['vectors']
checks=[]
def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)
def pairs(items):
    result={}
    for k,v in items:
        assert k not in result
        result[k]=v
    return result
required={f'{prefix}{i:02}' for prefix, count in [('S',14),('J',12),('F',12),('B',8),('T',6),('I',6)] for i in range(1,count+1)}
check('64 unique cases; 58 required plus L01..L06',len(V)==64 and {r['vector_id'] for r in V}==required|{f'L{i:02}' for i in range(1,7)})
classes={'VALID_COMPLETE_DOMAIN','SCALAR_FRAGMENT_EXACT_BYTES','FRAMING_COMPONENT_EXACT_BYTES','CONTRACT_REFUSAL_ONLY','RELATIONAL_ASSERTION_ONLY','BLOCKED_BY_RESOURCE_SCHEMA','DEFERRED_TO_FUTURE_DOMAIN_ORACLE'}
fields={'vector_id','vector_version','class','contract_clause_pointer','source_ref','input_description','exact_input_bytes_hex','exact_scalar_or_payload_bytes_hex','exact_frame_bytes_hex','expected_raw_sha256','expected_frame_sha256','expected_envelope_fields','expected_relation_or_refusal','status','blocked_prerequisite','authoring_method','limitations','review_state'}
byid={r['vector_id']:r for r in V}
for r in V:
    vid=r['vector_id']
    check(vid+' mandatory fields and one known class', fields<=r.keys() and r['class'] in classes)
    check(vid+' PENDING_INDEPENDENT_REVIEW',r['review_state']=='PENDING_INDEPENDENT_REVIEW')
    check(vid+' per-vector expected matches aggregate',json.loads((ROOT/'vectors'/vid/'expected.json').read_text())==r)
    check(vid+' nonempty documented expectation and source pointers',bool(r['expected_relation_or_refusal']) and bool(r['contract_clause_pointer']))
    for p in r['contract_clause_pointer'] + (r['source_ref'] if isinstance(r['source_ref'],list) else []):
        src=next(s for s in INV['sources'] if s['repo_path']==p['repo_path'])
        check(vid+' source pointer range '+p['clause'],p['commit']==INV['head'] and p['git_blob_sha1']==src['git_blob_sha1'] and 1<=p['lines'][0]<=p['lines'][1]<=len((ROOT/src['snapshot']).read_text().splitlines()))
    if r['class']!='VALID_COMPLETE_DOMAIN':
        check(vid+' no official frame/digest/envelope', all(r[k] is None for k in ['exact_frame_bytes_hex','expected_raw_sha256','expected_frame_sha256','expected_envelope_fields']))
        check(vid+' no complete positive filenames',not any(a['name'] in {'canonical_payload','frame','raw_body'} for a in r['artifacts']))
    if r['class'] in {'BLOCKED_BY_RESOURCE_SCHEMA','DEFERRED_TO_FUTURE_DOMAIN_ORACLE'}:
        check(vid+' missing prerequisite explicit',bool(r['blocked_prerequisite']))
    if r['class'] in {'SCALAR_FRAGMENT_EXACT_BYTES','FRAMING_COMPONENT_EXACT_BYTES'}:
        check(vid+' exact component bytes present',bool(r['exact_scalar_or_payload_bytes_hex']))
    for a in r['artifacts']:
        b=(ROOT/a['bin']).read_bytes()
        check(vid+' '+a['name']+' full binary / hex length',len(b)==a['byte_length'] and bytes.fromhex((ROOT/a['hex']).read_text())==b)
        if 'utf8_file' in a:
            check(vid+' '+a['name']+' UTF8 exact',b.decode('utf-8').encode('utf-8')==(ROOT/a['utf8_file']).read_bytes())
        role=a['role']
        key='exact_input_bytes_hex' if role=='INPUT' else 'exact_scalar_or_payload_bytes_hex'
        if role=='FRAME':check(vid+' frame hex metadata',r['exact_frame_bytes_hex']==b.hex())
        else:check(vid+' '+a['name']+' hex metadata',r[key][a['name']]==b.hex())
    if r['class']=='VALID_COMPLETE_DOMAIN':
        b=(ROOT/'vectors'/vid/'raw_body.bin').read_bytes()
        p=(ROOT/'vectors'/vid/'canonical_payload.bin').read_bytes()
        f=(ROOT/'vectors'/vid/'frame.bin').read_bytes()
        obj=json.loads(p,object_pairs_hook=pairs)
        check(vid+' exact three schema keys in byte order',list(obj)==['body_byte_length','body_sha256','canonical_profile_version'])
        check(vid+' profile literal',obj['canonical_profile_version']=='typed-json-candidate-v0.1')
        u=obj['body_byte_length']
        check(vid+' typed raw length',list(u)==['type','value'] and u['type']=='uint64' and u['value']==str(len(b)) and type(u['value']) is str)
        check(vid+' lowercase raw SHA',re.fullmatch('[0-9a-f]{64}',obj['body_sha256']) is not None and obj['body_sha256']==hashlib.sha256(b).hexdigest()==r['expected_raw_sha256'])
        # Token-level fixed-layout audit independent of the author concatenation code.
        check(vid+' payload is exact canonical ASCII token sequence',
            re.fullmatch(rb'\{"body_byte_length":\{"type":"uint64","value":"[0-3]"\},"body_sha256":"[0-9a-f]{64}","canonical_profile_version":"typed-json-candidate-v0\.1"\}',p) is not None)
        segments=[];off=0
        for index in range(3):
            prefix_start=off
            n=int.from_bytes(f[off:off+8],'big');off+=8
            seg=f[off:off+n]
            d=r['frame_dissection'][index]
            check(vid+' dissection'+str(index), d['prefix_start']==prefix_start and d['prefix_end_exclusive']==off and d['data_start']==off and d['byte_length']==n and d['data_end_exclusive']==off+n and d['prefix_hex']==f[prefix_start:off].hex())
            segments.append(seg);off+=n
        check(vid+' complete parser consumes exact281',off==len(f)==281 and len(p)==187 and len(f)==24+sum(map(len,segments)))
        check(vid+' registry D/S/P segments',segments==[b'PITLAB/ACADEMIC/SOURCE-BYTES/candidate-v0.1',b'source-bytes-candidate-v0.1',p])
        dg=hashlib.sha256(f).hexdigest();e=r['expected_envelope_fields']
        check(vid+' frame digest lowercase64',re.fullmatch('[0-9a-f]{64}',dg) is not None and dg==r['expected_frame_sha256'])
        check(vid+' exact six envelope core fields',set(e)=={'domain_tag','object_schema_version','canonical_profile_version','digest_algorithm','canonical_payload_byte_length','digest_hex'})
        check(vid+' envelope identity / payload-only length',e=={'domain_tag':segments[0].decode(),'object_schema_version':segments[1].decode(),'canonical_profile_version':obj['canonical_profile_version'],'digest_algorithm':'SHA-256','canonical_payload_byte_length':{'type':'uint64','value':str(len(p))},'digest_hex':dg})
        check(vid+' BODY/PAYLOAD-audit/FRAME labels separated',len({hashlib.sha256(x).digest() for x in [b,p,f]})==3 and r['expected_payload_sha256_audit_only']==hashlib.sha256(p).hexdigest())
        derivation=(ROOT/'vectors'/vid/'derivation.md').read_text()
        check(vid+' manual complete hex and fixed length arithmetic',p.hex() in derivation and f.hex() in derivation and '46+1+18+64+58=187' in derivation)

# Select sensitive exact fragments from independently written constants/UTF-8 codepoints.
for vid,raw in [('S01',b'{"type":"int64","value":"0"}'),('S02',b'{"type":"int64","value":"140"}'),
                ('S03',b'{"type":"int64","value":"-9223372036854775808"}'),('S04',b'{"type":"int64","value":"9223372036854775807"}'),
                ('S06',b'{"type":"uint64","value":"18446744073709551615"}')]:
    check(vid+' numeric literal audit',(ROOT/'vectors'/vid/'scalar.bin').read_bytes()==raw)
check('J02 Unicode distinction', (ROOT/'vectors/J02/nfc_quoted.bin').read_bytes()=='"\u00e9"'.encode('utf-8') and (ROOT/'vectors/J02/nfd_quoted.bin').read_bytes()=='"e\u0301"'.encode('utf-8'))
check('J04 lowercase no short escape', (ROOT/'vectors/J04/escaped.bin').read_bytes().hex()=='225c75303030615c75303030395c75303030305c753030316622')
check('J12 content bytes not chars',len('\u00e9'.encode('utf-8'))*32768==65536)
check('B01 zero-body vs nonzero payload',(ROOT/'vectors/B01/raw_body.bin').read_bytes()==b'' and byid['B01']['canonical_payload_byte_length']==187)
check('B06 opaque ff body',(ROOT/'vectors/B06/raw_body.bin').read_bytes()==bytes([255]))
for a,b in [('B02','B08'),('B04','B05')]:
    check(a+'/'+b+' raw and FRAME digests distinct',byid[a]['expected_raw_sha256']!=byid[b]['expected_raw_sha256'] and byid[a]['expected_frame_sha256']!=byid[b]['expected_frame_sha256'])
    check(a+'/'+b+' payload bytes distinct',(ROOT/'vectors'/a/'canonical_payload.bin').read_bytes()!=(ROOT/'vectors'/b/'canonical_payload.bin').read_bytes())
check('T03 observed four historical pins unchanged',byid['T03']['components']['wu04_tick_sha256_pins']==[
 '909050c0cc90f0e16361891e9fa2b2233a363aa35de5278a38b838d97baea046',
 'be50dadac52fee5a266b56dbd4448275cf331078af554050713bcdf4471fe1fa',
 '56c8ca0ff123301adc894e65738209c7987e91d31a9c9b35597e3ae44c0abed8',
 'beaf6dff59c87f22f9384a5d1ce3017a1192dbf2167e51b0c9b54d389eb107e8'])
for path in ROOT.rglob('*'):
    info=path.lstat()
    check('regular single-link external entry '+path.relative_to(ROOT).as_posix(),not path.is_symlink() and (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode) and info.st_nlink==1))
    check('no bytecode cache '+path.name,path.name!='__pycache__' and path.suffix!='.pyc')
receipts=[]
def git(*args):
    argv=['git','--no-optional-locks','-C',INV['top_level'],*args]
    p=subprocess.run(argv,capture_output=True,text=True,check=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    receipts.append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    return p.stdout.rstrip('\n')
check('HEAD/branch/status/origin unchanged',git('rev-parse','HEAD')==INV['head'] and git('branch','--show-current')=='main' and git('status','--porcelain=v1','--untracked-files=all')=='' and git('rev-parse','origin/main')==INV['head'])
for s in INV['sources']:
    b=(Path(INV['top_level'])/s['repo_path']).read_bytes()
    check('original allowlisted source bytes unchanged '+s['repo_path'],len(b)==s['raw_byte_length'] and hashlib.sha256(b).hexdigest()==s['raw_sha256'] and (ROOT/s['snapshot']).read_bytes()==b)
INV.update(repo_dirty_after=False,status_after_porcelain='',end_baseline_receipts=receipts,
           final_scope='Formal metadata via Git only; Formal source/runtime not inspected')
(ROOT/'source_contract_inventory.json').write_text(json.dumps(INV,ensure_ascii=False,indent=2)+'\n')
scope=json.loads((ROOT/'oracle_scope_register.json').read_text())
check('scope counts',scope['class_counts']==dict(Counter(r['class'] for r in V)))
result={'author_self_check':'PASS','evidence_class':'AUTHOR_SELF_CHECK_ONLY',
        'checks_count':len(checks),'checks':checks,'case_counts':scope['class_counts'],
        'repo_dirty_before':False,'repo_dirty_after':False,'source_contract_pins':'PASS',
        'production_codec_conformance':'NOT_RUN','native_replay':'NOT_RUN','independent_review':'NOT_RUN',
        'golden_freeze':'NOT_AUTHORIZED',
        'limitations':'Structural/literal consistency only. Refusal and relational outcomes are documentary, not observed runtime validation. Independent reviewer must reconstruct fresh preimages.'}
(ROOT/'author_self_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('AUTHOR_SELF_CHECK=PASS')
print('CHECKS_COUNT='+str(len(checks)))
print('PRODUCT_CODEC=NOT_RUN INDEPENDENT_REVIEW=NOT_RUN')
