"""Final package/read-only Git receipt, AUTHOR_SELF_CHECK_ONLY; not independent review."""
import hashlib
import json
import os
import platform
import stat
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

R=Path(__file__).resolve().parents[1]
zpath=R/'IF03_ORACLE01_Review_Evidence.zip'
manifest=json.loads((R/'MANIFEST.json').read_text())
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    members=z.namelist()
    assert len(members)==len(set(members)) and members==sorted(members)
    assert set(members)=={'MANIFEST.json'}|{e['path'] for e in manifest['files']}
    assert z.read('MANIFEST.json')==(R/'MANIFEST.json').read_bytes()
    for i in z.infolist():
        p=PurePosixPath(i.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
        assert not i.flag_bits&1 and stat.S_ISREG(i.external_attr>>16)
    for e in manifest['files']:
        data=z.read(e['path'])
        assert len(data)==e['byte_length'] and hashlib.sha256(data).hexdigest()==e['sha256']
        assert (R/e['path']).read_bytes()==data
scope=json.loads((R/'oracle_scope_register.json').read_text())
vectors=json.loads((R/'oracle_vectors.json').read_text())['vectors']
matrix=json.loads((R/'vector_case_matrix.json').read_text())['case_rows']
assert {v['vector_id'] for v in vectors}=={v['vector_id'] for v in scope['vectors']}=={v['vector_id'] for v in matrix}
for v,short,m in zip(vectors,scope['vectors'],matrix,strict=True):
    assert v['vector_id']==short['vector_id']==m['vector_id'] and v['class']==short['class']==m['class']
    for k in m:assert m[k]==v[k]
# Original executed source is preserved even though author template was corrected.
receipt=json.loads((R/'execution/author_cases.receipt.json').read_text())
assert hashlib.sha256((R/'authoring_sources/author_cases.executed-v0.py').read_bytes()).hexdigest()==receipt['script_raw_sha256']
for name in ['author_cases','self_check','capture_baseline','revise_candidates']:
    item=json.loads((R/'execution'/(name+'.receipt.json')).read_text())
    assert hashlib.sha256((R/item['stdout_file']).read_bytes()).hexdigest()==item['stdout_sha256']
    assert hashlib.sha256((R/item['stderr_file']).read_bytes()).hexdigest()==item['stderr_sha256']
repo='/home/rooki/projects/pit-research-lab-mvp'
receipts=[]
for args in [('rev-parse','--show-toplevel'),('branch','--show-current'),('rev-parse','HEAD'),('rev-parse','origin/main'),('status','--porcelain=v1','--untracked-files=all')]:
    argv=['git','--no-optional-locks','-C',repo,*args]
    p=subprocess.run(argv,capture_output=True,text=True,check=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    receipts.append({'argv':argv,'stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode})
assert [p['stdout'].rstrip('\n') for p in receipts]==[repo,'main','9ade777ac03052231088a91ef9849c5a506da184','9ade777ac03052231088a91ef9849c5a506da184','']
assert not (R/'packaging_stderr.txt').read_bytes()
digest=hashlib.sha256(zpath.read_bytes()).hexdigest()
assert 'ZIP_SHA256='+digest in (R/'packaging_stdout.txt').read_text()
out={'package_integrity':'PASS','evidence_class':'AUTHOR_SELF_CHECK_ONLY',
     'independent_review':'NOT_RUN','zip_sha256':digest,'zip_byte_length':zpath.stat().st_size,
     'zip_members':len(members),'manifest_full_coverage':'PASS','zip_crc':'PASS','safe_regular_members':'PASS',
     'source_contract_pin_status':'PASS','repo_dirty_before':False,'repo_dirty_after':False,
     'repo_final_receipts':receipts,'interpreter':platform.python_version(),
     'packaging_command':['python3','-B',str(R/'authoring_sources/package_evidence.py')],
     'packaging_stdout_sha256':hashlib.sha256((R/'packaging_stdout.txt').read_bytes()).hexdigest(),
     'packaging_stderr_sha256':hashlib.sha256((R/'packaging_stderr.txt').read_bytes()).hexdigest(),
     'delivery_verifier_command':['python3','-B',str(Path(__file__))],
     'delivery_verifier_stdout':'DELIVERY_VERIFICATION=PASS\nZIP_SHA256='+digest+'\nREPO_DIRTY_AFTER=false\n',
     'delivery_verifier_stderr':''}
with (R/'package_validation.json').open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
paths=[R/n for n in members]+[zpath,R/'packaging_stdout.txt',R/'packaging_stderr.txt',R/'package_validation.json']
with (R/'SHA256SUMS').open('x') as f:
    for p in sorted(paths,key=lambda p:p.relative_to(R).as_posix()):
        assert p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
        f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n')
for line in (R/'SHA256SUMS').read_text().splitlines():
    dg,name=line.split('  ',1)
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==dg
print('DELIVERY_VERIFICATION=PASS')
print('ZIP_SHA256='+digest)
print('REPO_DIRTY_AFTER=false')
