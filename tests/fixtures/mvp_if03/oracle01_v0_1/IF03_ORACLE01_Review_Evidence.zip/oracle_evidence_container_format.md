# ORACLE01_EVIDENCE_CONTAINER_v0.1

此 JSON 是外部 evidence metadata，**不是 CanonicalPayload、Domain 或 Resource schema**；JSON numbers/null、pretty printing 與中文可用於此容器，不可套用成 App payload。`oracle_vector.schema.json` 定義有限允許 keys、required keys 與 top-level types；未宣稱執行第三方 JSON Schema validator。

`oracle_vectors.json.vectors[]` 與每個 `vectors/<ID>/expected.json` 必須逐 JSON value 相同。`oracle_scope_register.json.vectors[]` 只做一對一索引；matrix 是同一組64 cases的審查投影，並非另一批測試。每 row 僅一個 class；64中58為需求ID、L01..L06為補充，不能用substimuli增加計數。

`exact_input_bytes_hex`、`exact_scalar_or_payload_bytes_hex` 是 artifact-name→完整lowercase hex 的 maps；空body用空hex字串。`exact_frame_bytes_hex` 只有 VALID_COMPLETE_DOMAIN 可非null；invalid frame stimuli只在 input map，不能被當成 expected成功frame。`expected_raw_sha256`、`expected_frame_sha256`、`expected_envelope_fields` 限完整SOURCE-BYTES；其他case必為null。`expected_payload_sha256_audit_only` 只是P檔audit hash，不能代替frame digest。Artifact manifest/checksums 的 SHA-256 亦只是 package integrity。

`artifacts[]` 記錄 name、role（INPUT / SCALAR_OR_PAYLOAD / FRAMING_COMPONENT / FRAME）、bin、hex、byte_length；UTF-8可解碼則加 `utf8_file`（內容完全相同，無附加換行），否則 `utf8_rendering=UNDEFINED_INVALID_UTF8`。不可把任一 .utf8.txt 當成有lossy replacement的preview。B01空 `.bin` 與空 rendering均刻意保留。

`contract_clause_pointer[]` 與 repository-based `source_ref[]` 使用 repo_path、commit、git_blob_sha1、lines=[start,end]（含端點）、clause。SELF_CONTAINED_SYNTHETIC 的cases亦有已pin contract pointers；各來源的完整raw snapshot與inventory可用於不連線逐行核對。T01..T04引用的是已提交 assertions及literal WU04 pins，不是本輪重新執行／重新驗證Native source bodies。

`components` 為 case-specific documentary資料，內部labels不是Domain/Resource IDs；recipes指定未物化的大型刺激，不表示執行或接受。拒絕類別採敘述，僅 REF_CYCLE 與 REF_UNAPPROVED_RESOURCE_SCHEMA 引用實際contract既有code，不發明實作error constants。Mixed-outcome challenge如S14只有一個primary class BLOCKED_BY_RESOURCE_SCHEMA，component agreement/mismatch規格保留在同row；不強行產生完整positive。

status 是本 evidence container 的 authoring disposition，不是 App lifecycle。review_state 全為 PENDING_INDEPENDENT_REVIEW；freeze_status同值，無 FROZEN。分類、keys、scope counts、逐檔hex與binary一致性由作者self-check檢查；這不等於schema語義/independent review/product Codec測試。
